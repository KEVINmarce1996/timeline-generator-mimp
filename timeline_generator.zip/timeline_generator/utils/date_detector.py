"""
date_detector.py
Detecta y normaliza fechas en texto libre, celdas de Excel, filas de tabla,
etc. Devuelve siempre objetos datetime o rangos (inicio, fin).

Soporta:
  - Fechas exactas: "15/03/2024", "March 2024", "15 de marzo de 2024"
  - Solo año: "2024", "año 2025"
  - Rangos: "enero - marzo 2024", "2022 al 2024"
  - Meses abreviados: "Ene", "Feb", "Mar" ...
  - Hitos sin fecha (se registran como eventos sin fecha pero con posición)
"""

from __future__ import annotations

import re
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Optional

import dateparser

logger = logging.getLogger(__name__)


# ── Granularidad de fecha ─────────────────────────────────────────────────────

class DateGranularity(Enum):
    YEAR    = auto()   # Solo año conocido
    MONTH   = auto()   # Año + mes conocido
    EXACT   = auto()   # Fecha completa
    RANGE   = auto()   # Rango (fecha_inicio, fecha_fin)
    UNKNOWN = auto()   # No se pudo detectar fecha


# ── Resultado de detección ────────────────────────────────────────────────────

@dataclass
class DetectedDate:
    raw_text: str
    granularity: DateGranularity
    date_start: Optional[datetime] = None
    date_end:   Optional[datetime] = None
    confidence: float = 1.0         # 0.0 – 1.0

    @property
    def year(self) -> Optional[int]:
        return self.date_start.year if self.date_start else None

    @property
    def month(self) -> Optional[int]:
        return self.date_start.month if self.date_start and self.granularity != DateGranularity.YEAR else None

    def display_label(self, config: "DetectorConfig") -> str:
        """Etiqueta de visualización según granularidad y configuración."""
        if self.date_start is None:
            return self.raw_text

        if config.granularity == "annual" or self.granularity == DateGranularity.YEAR:
            return str(self.date_start.year)

        if self.granularity == DateGranularity.MONTH:
            return self.date_start.strftime("%b %Y")

        if self.granularity == DateGranularity.RANGE:
            start = self.date_start.strftime("%b %Y") if config.granularity == "monthly" else str(self.date_start.year)
            end   = self.date_end.strftime("%b %Y")   if config.granularity == "monthly" and self.date_end else (str(self.date_end.year) if self.date_end else "")
            return f"{start} – {end}"

        return self.date_start.strftime("%d/%m/%Y")


@dataclass
class DetectorConfig:
    granularity: str = "annual"     # "annual" | "monthly"
    language: str    = "es"         # idioma preferido para dateparser


# ── Detector ──────────────────────────────────────────────────────────────────

class DateDetector:
    """
    Detecta fechas en texto arbitrario.

    Uso:
        detector = DateDetector(DetectorConfig(granularity="monthly"))
        result = detector.detect("Contrato firmado el 15 de marzo de 2024")
        print(result.display_label(detector.config))  # "Mar 2024"
    """

    # Patrones de año puro (4 dígitos entre 1900 y 2100)
    _RE_YEAR = re.compile(r'\b(1[9]\d{2}|20[0-9]{2}|21\d{2})\b')

    # Patrones de rango año-año: "2022-2024", "2022 al 2024", "2022 a 2024"
    _RE_YEAR_RANGE = re.compile(
        r'\b(1[9]\d{2}|20[0-9]{2})\s*(?:[-–—]|al?|a)\s*(1[9]\d{2}|20[0-9]{2})\b',
        re.IGNORECASE,
    )

    # Patrones de mes + año: "enero 2024", "Ene-2024", "01/2024"
    _RE_MONTH_YEAR = re.compile(
        r'\b(?:ene(?:ro)?|feb(?:rero)?|mar(?:zo)?|abr(?:il)?|may(?:o)?|jun(?:io)?|'
        r'jul(?:io)?|ago(?:sto)?|sep(?:tiembre)?|oct(?:ubre)?|nov(?:iembre)?|dic(?:iembre)?|'
        r'jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|'
        r'aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)'
        r'[\s\-/]*(\d{4})\b',
        re.IGNORECASE,
    )

    _DATEPARSER_SETTINGS = {
        "RETURN_AS_TIMEZONE_AWARE": False,
        "PREFER_DAY_OF_MONTH": "first",
    }

    def __init__(self, config: Optional[DetectorConfig] = None):
        self.config = config or DetectorConfig()

    # ── API pública ───────────────────────────────────────────────────────────

    def detect(self, text: str) -> DetectedDate:
        """Intenta detectar la fecha más relevante en el texto."""
        if not text or not text.strip():
            return DetectedDate(raw_text=text, granularity=DateGranularity.UNKNOWN)

        text = str(text).strip()

        # 1. ¿Es solo un número de 4 dígitos (año)?
        if re.fullmatch(r'\d{4}', text):
            return self._make_year(text, int(text))

        # 2. ¿Es un rango de años?
        m = self._RE_YEAR_RANGE.search(text)
        if m:
            return self._make_range(text, int(m.group(1)), int(m.group(2)))

        # 3. ¿Contiene mes + año?
        m = self._RE_MONTH_YEAR.search(text)
        if m:
            parsed = dateparser.parse(
                text,
                languages=[self.config.language, "en"],
                settings=self._DATEPARSER_SETTINGS,
            )
            if parsed:
                return DetectedDate(
                    raw_text=text,
                    granularity=DateGranularity.MONTH,
                    date_start=parsed,
                    confidence=0.9,
                )

        # 4. Intentar dateparser genérico
        parsed = dateparser.parse(
            text,
            languages=[self.config.language, "en"],
            settings=self._DATEPARSER_SETTINGS,
        )
        if parsed:
            granularity = self._infer_granularity(text, parsed)
            return DetectedDate(
                raw_text=text,
                granularity=granularity,
                date_start=parsed,
                confidence=0.75,
            )

        # 5. Buscar año suelto en texto más largo
        years = self._RE_YEAR.findall(text)
        if len(years) >= 2:
            return self._make_range(text, int(years[0]), int(years[-1]))
        if len(years) == 1:
            return self._make_year(text, int(years[0]))

        logger.debug("Sin fecha detectada en: %r", text)
        return DetectedDate(raw_text=text, granularity=DateGranularity.UNKNOWN, confidence=0.0)

    def detect_all(self, text: str) -> list[DetectedDate]:
        """Detecta TODAS las fechas presentes en un texto (útil para párrafos)."""
        results = []

        # Rangos primero
        for m in self._RE_YEAR_RANGE.finditer(text):
            results.append(self._make_range(m.group(0), int(m.group(1)), int(m.group(2))))

        # Años sueltos que no estén dentro de un rango ya detectado
        range_spans = {m.span() for m in self._RE_YEAR_RANGE.finditer(text)}
        for m in self._RE_YEAR.finditer(text):
            in_range = any(s <= m.start() < e for s, e in range_spans)
            if not in_range:
                results.append(self._make_year(m.group(0), int(m.group(0))))

        # Mes+año
        for m in self._RE_MONTH_YEAR.finditer(text):
            parsed = dateparser.parse(
                m.group(0),
                languages=[self.config.language, "en"],
                settings=self._DATEPARSER_SETTINGS,
            )
            if parsed:
                results.append(DetectedDate(
                    raw_text=m.group(0),
                    granularity=DateGranularity.MONTH,
                    date_start=parsed,
                    confidence=0.85,
                ))

        # Ordenar cronológicamente
        results.sort(key=lambda d: d.date_start or datetime.min)
        return results

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _make_year(raw: str, year: int) -> DetectedDate:
        return DetectedDate(
            raw_text=raw,
            granularity=DateGranularity.YEAR,
            date_start=datetime(year, 1, 1),
            confidence=1.0,
        )

    @staticmethod
    def _make_range(raw: str, year_start: int, year_end: int) -> DetectedDate:
        return DetectedDate(
            raw_text=raw,
            granularity=DateGranularity.RANGE,
            date_start=datetime(year_start, 1, 1),
            date_end=datetime(year_end, 12, 31),
            confidence=1.0,
        )

    @staticmethod
    def _infer_granularity(text: str, parsed: datetime) -> DateGranularity:
        # Si el texto contiene día explícito → EXACT
        if re.search(r'\b\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{4}\b', text):
            return DateGranularity.EXACT
        # Si contiene nombre de mes → MONTH
        month_names = (
            "enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|"
            "octubre|noviembre|diciembre|january|february|march|april|may|"
            "june|july|august|september|october|november|december"
        )
        if re.search(month_names, text, re.IGNORECASE):
            return DateGranularity.MONTH
        return DateGranularity.YEAR


# ── Test rápido ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    cfg = DetectorConfig(granularity="monthly")
    d = DateDetector(cfg)

    samples = [
        "2024",
        "2019-2024",
        "Proceso iniciado en marzo de 2023",
        "Contrato vigente de enero 2022 al diciembre 2023",
        "15/03/2024",
        "sin fecha",
        "Ene-2026",
        "…",
    ]
    for s in samples:
        r = d.detect(s)
        print(f"  {s!r:45} → {r.granularity.name:8} | {r.display_label(cfg)}")
