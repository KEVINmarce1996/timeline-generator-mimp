"""
vision_parser.py  v3
Extrae información cronológica de imágenes usando Gemini 2.5 Flash.

Especializado en:
  1. Tablas de cronograma SEACE (Etapa / Fecha Inicio / Fecha Fin)
  2. Imágenes de timelines genéricas
  3. Imágenes embebidas en DOCX
"""
from __future__ import annotations
import base64, io, json, logging, os, re, time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# ── Prompts ───────────────────────────────────────────────────────────────────

_PROMPT_SEACE = """
Esta imagen es un cronograma del sistema SEACE del Estado peruano.
Contiene una tabla con columnas: Etapa, Fecha Inicio, Fecha Fin.

Extrae TODA la información y responde ÚNICAMENTE con este JSON (sin markdown, sin texto extra):

{
  "tipo": "seace_cronograma",
  "project_title": "nombre del proceso si aparece, sino cadena vacía",
  "etapas": [
    {
      "etapa": "nombre exacto de la etapa",
      "fecha_inicio": "dd/mm/yyyy",
      "fecha_fin": "dd/mm/yyyy"
    }
  ]
}

Reglas:
- Extrae las fechas en formato dd/mm/yyyy (ignora las horas)
- Incluye TODAS las filas de la tabla, incluso las resaltadas en amarillo
- Si no ves una tabla SEACE, responde: {"tipo": "otro", "etapas": []}
"""

_PROMPT_GENERICO = """
Analiza esta imagen. Puede ser una línea de tiempo, cronograma, diagrama de Gantt o tabla con fechas.

Extrae toda la información cronológica y responde ÚNICAMENTE con este JSON (sin markdown):

{
  "tipo": "timeline_generico",
  "project_title": "título del proyecto si aparece",
  "sections": [
    {
      "section_name": "nombre de la sección o fase",
      "events": [
        {
          "label": "descripción del evento",
          "date": "fecha en formato dd/mm/yyyy o mm/yyyy o yyyy",
          "date_end": "fecha fin si aplica, sino igual que date"
        }
      ]
    }
  ]
}

Si no encuentras información cronológica: {"tipo": "sin_datos", "sections": []}
"""

# ── Resultado ─────────────────────────────────────────────────────────────────

@dataclass
class VisionResult:
    tipo: str = "desconocido"       # "seace_cronograma" | "timeline_generico" | "sin_datos" | "error"
    project_title: str = ""
    etapas: list[dict] = field(default_factory=list)   # para SEACE
    sections: list[dict] = field(default_factory=list) # para genérico
    raw_text: str = ""
    source: str = ""
    success: bool = True
    error: str = ""


# ── Cliente Gemini ────────────────────────────────────────────────────────────

class GeminiClient:
    MODEL       = "gemini-2.5-flash"
    MAX_RETRIES = 3
    DELAYS      = [3, 8, 20]
    _instance   = None

    def __init__(self, api_key: str):
        from google import genai
        self._client = genai.Client(api_key=api_key)
        self._calls  = 0

    @classmethod
    def get(cls) -> "GeminiClient":
        if cls._instance:
            return cls._instance
        key = cls._find_key()
        cls._instance = cls(key)
        return cls._instance

    @classmethod
    def _find_key(cls) -> str:
        k = os.environ.get("GOOGLE_API_KEY", "").strip()
        if k: return k
        try:
            from google.colab import userdata
            k = userdata.get("GOOGLE_API_KEY")
            if k: return k
        except Exception:
            pass
        raise EnvironmentError(
            "GOOGLE_API_KEY no encontrada.\n"
            "En Colab: activa el Secret 'GOOGLE_API_KEY' en el panel de la izquierda (🔑).\n"
            "En local: export GOOGLE_API_KEY=tu_clave"
        )

    def call(self, img_bytes: bytes, mime: str, prompt: str) -> str:
        from google import genai
        from google.genai import types
        for attempt in range(self.MAX_RETRIES):
            try:
                r = self._client.models.generate_content(
                    model=self.MODEL,
                    contents=[
                        types.Part.from_bytes(data=img_bytes, mime_type=mime),
                        prompt,
                    ],
                )
                self._calls += 1
                return r.text or ""
            except Exception as e:
                s = str(e).lower()
                if ("429" in s or "quota" in s or "rate" in s) and attempt < self.MAX_RETRIES - 1:
                    wait = self.DELAYS[attempt]
                    logger.warning("Rate limit. Reintentando en %ds…", wait)
                    time.sleep(wait)
                    continue
                raise RuntimeError(f"Gemini API error: {e}") from e
        return ""


# ── VisionParser ──────────────────────────────────────────────────────────────

class VisionParser:
    def __init__(self):
        self._client: Optional[GeminiClient] = None

    @property
    def client(self) -> GeminiClient:
        if not self._client:
            self._client = GeminiClient.get()
        return self._client

    @property
    def is_available(self) -> bool:
        try: _ = self.client; return True
        except: return False

    # ── API pública ───────────────────────────────────────────────────────────

    def parse_image(self, path: Path) -> VisionResult:
        mime_map = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg"}
        mime     = mime_map.get(path.suffix.lower(), "image/png")
        try:
            return self._process(path.read_bytes(), mime, source=path.name)
        except Exception as e:
            return VisionResult(tipo="error", source=path.name, success=False, error=str(e))

    def parse_docx_images(self, path: Path) -> list[VisionResult]:
        results = []
        images  = self._extract_docx_images(path)
        if not images:
            return []
        for i, (img_bytes, mime) in enumerate(images, 1):
            try:
                r = self._process(img_bytes, mime, source=f"{path.name}::img{i}")
                results.append(r)
            except Exception as e:
                results.append(VisionResult(
                    tipo="error", source=f"{path.name}::img{i}",
                    success=False, error=str(e)
                ))
            if i < len(images):
                time.sleep(0.5)
        return results

    def parse_pdf_page(self, img_bytes: bytes, source: str) -> VisionResult:
        return self._process(img_bytes, "image/png", source=source)

    # ── Procesamiento central ─────────────────────────────────────────────────

    def _process(self, img_bytes: bytes, mime: str, source: str) -> VisionResult:
        """
        Estrategia de 2 pasos:
        1. Intentar con prompt SEACE (más preciso si es tabla de cronograma)
        2. Si no retorna etapas, usar prompt genérico
        """
        logger.info("Vision procesando: %s", source)

        # Paso 1: prompt SEACE
        raw = self.client.call(img_bytes, mime, _PROMPT_SEACE)
        result = self._parse_json(raw, source)

        if result.tipo == "seace_cronograma" and result.etapas:
            logger.info("  → SEACE detectado: %d etapas", len(result.etapas))
            return result

        # Paso 2: prompt genérico
        time.sleep(0.3)
        raw2   = self.client.call(img_bytes, mime, _PROMPT_GENERICO)
        result2 = self._parse_json(raw2, source)
        if result2.sections or result2.etapas:
            return result2

        # Fallback: devolver lo que tengamos del paso 1
        return result

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _parse_json(raw: str, source: str) -> VisionResult:
        clean = raw.strip()
        # Quitar bloques ```json ... ``` si Gemini los incluye
        clean = re.sub(r'^```(?:json)?\s*', '', clean, flags=re.MULTILINE)
        clean = re.sub(r'```\s*$', '', clean, flags=re.MULTILINE)
        clean = clean.strip()
        try:
            data = json.loads(clean)
            return VisionResult(
                tipo          = data.get("tipo", "desconocido"),
                project_title = data.get("project_title", ""),
                etapas        = data.get("etapas", []),
                sections      = data.get("sections", []),
                raw_text      = raw,
                source        = source,
                success       = True,
            )
        except json.JSONDecodeError:
            logger.debug("JSON inválido de Gemini, guardando como raw_text")
            return VisionResult(raw_text=raw, source=source, tipo="raw")

    @staticmethod
    def _extract_docx_images(path: Path) -> list[tuple[bytes, str]]:
        import zipfile
        mime_map = {".png":"image/png",".jpg":"image/jpeg",".jpeg":"image/jpeg",
                    ".gif":"image/gif",".bmp":"image/bmp"}
        results = []
        try:
            with zipfile.ZipFile(path) as z:
                for f in z.namelist():
                    if "word/media/" in f:
                        ext  = Path(f).suffix.lower()
                        mime = mime_map.get(ext)
                        if mime:
                            results.append((z.read(f), mime))
        except Exception as e:
            logger.warning("Error extrayendo imágenes de %s: %s", path.name, e)
        return results


# ── Función de integración con file_parser ────────────────────────────────────

def enrich_with_vision(parse_result, filepath: Path,
                        vision: VisionParser, config) -> None:
    """
    Enriquece un ParseResult con eventos extraídos visualmente.
    Especializado para SEACE y timelines genéricos.
    """
    from core.file_parser import TimelineEvent
    from utils.date_detector import DateDetector, DateGranularity
    from datetime import datetime

    ext = filepath.suffix.lower()

    if ext in (".png", ".jpg", ".jpeg"):
        vision_results = [vision.parse_image(filepath)]
    elif ext == ".docx":
        vision_results = vision.parse_docx_images(filepath)
    elif ext == ".pdf":
        vision_results = _process_pdf(filepath, vision)
    else:
        return

    for vr in vision_results:
        if not vr.success:
            parse_result.warnings.append(f"Vision [{vr.source}]: {vr.error}")
            continue

        # ── Caso SEACE: tabla estructurada ────────────────────────────────────
        if vr.tipo == "seace_cronograma" and vr.etapas:
            if not parse_result.project_title and vr.project_title:
                parse_result.project_title = vr.project_title
            for item in vr.etapas:
                etapa = item.get("etapa", "").strip()
                fi    = item.get("fecha_inicio", "").strip()
                ff    = item.get("fecha_fin", "").strip()
                if not etapa or not fi:
                    continue
                try:
                    dt_start = datetime.strptime(fi[:10], "%d/%m/%Y")
                    dt_end   = datetime.strptime(ff[:10], "%d/%m/%Y") if ff else dt_start
                except ValueError:
                    continue

                from utils.date_detector import DetectedDate, DateGranularity
                detected = DetectedDate(
                    raw_text    = fi,
                    granularity = DateGranularity.EXACT,
                    date_start  = dt_start,
                    date_end    = dt_end,
                    confidence  = 1.0,
                )
                parse_result.events.append(TimelineEvent(
                    label        = etapa,
                    detected_date= detected,
                    phase        = "PROCESO DE SELECCIÓN",
                    source_file  = vr.source,
                    raw_value    = f"{fi} → {ff}: {etapa}",
                ))

        # ── Caso genérico ─────────────────────────────────────────────────────
        elif vr.sections:
            detector = DateDetector(config)
            for section in vr.sections:
                phase = section.get("section_name", "General")
                for ev in section.get("events", []):
                    label    = ev.get("label", "")
                    date_str = ev.get("date", "")
                    detected = detector.detect(date_str) if date_str else None
                    if detected and detected.granularity != DateGranularity.UNKNOWN:
                        parse_result.events.append(TimelineEvent(
                            label        = label or detected.display_label(config),
                            detected_date= detected,
                            phase        = phase,
                            source_file  = vr.source,
                            raw_value    = f"{date_str}: {label}",
                        ))

        # Título
        if vr.project_title and not parse_result.project_title:
            parse_result.project_title = vr.project_title

    logger.info("Vision añadió %d eventos desde %s",
                len(parse_result.events), filepath.name)


def _process_pdf(path: Path, vision: VisionParser) -> list[VisionResult]:
    try:
        from pdf2image import convert_from_path
        import io as _io
        pages = convert_from_path(str(path), dpi=150, first_page=1, last_page=10)
        results = []
        for i, page in enumerate(pages, 1):
            buf = _io.BytesIO()
            page.save(buf, format="PNG")
            r = vision.parse_pdf_page(buf.getvalue(), f"{path.name}::p{i}")
            if r.success and (r.etapas or r.sections):
                results.append(r)
            time.sleep(0.4)
        return results
    except ImportError:
        return [VisionResult(tipo="error", source=path.name, success=False,
                             error="pdf2image no instalado: pip install pdf2image")]
