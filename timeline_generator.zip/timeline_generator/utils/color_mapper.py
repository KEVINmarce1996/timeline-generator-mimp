"""
color_mapper.py
Paleta de colores y estilos extraídos del workbook modelo formato_excel_modelo.xlsx.
Todos los valores RGB son exactos al archivo fuente.
"""

from dataclasses import dataclass
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter


# ── Colores base (RGB hex sin alpha) ──────────────────────────────────────────
AZUL_OSCURO   = "1F497D"   # Fondo cabecera de años
AZUL_CLARO    = "DCE6F2"   # Fondo banda de fases / etiquetas
BLANCO        = "FFFFFF"   # Texto sobre azul oscuro
NEGRO         = "000000"   # Texto sobre azul claro
GRIS_CLARO    = "F2F2F2"   # Fondo alternativo secciones
TRANSPARENTE  = "00000000" # Sin relleno (fgColor vacío en modelo)


@dataclass(frozen=True)
class CellStyle:
    """Encapsula todos los atributos de estilo de una celda."""
    fill_color: str        # hex RGB (6 chars)
    font_color: str        # hex RGB (6 chars)
    font_bold: bool
    font_size: float
    font_name: str
    h_align: str           # "center" | "left" | "right"
    v_align: str           # "center" | "top" | "bottom"
    wrap_text: bool


# ── Estilos canónicos extraídos del modelo ────────────────────────────────────

STYLE_YEAR_HEADER = CellStyle(
    fill_color=AZUL_OSCURO,
    font_color=BLANCO,
    font_bold=True,
    font_size=9.0,
    font_name="Calibri",
    h_align="center",
    v_align="center",
    wrap_text=False,
)

STYLE_PHASE_LABEL = CellStyle(
    fill_color=AZUL_CLARO,
    font_color=NEGRO,
    font_bold=True,
    font_size=8.0,
    font_name="Calibri",
    h_align="center",
    v_align="center",
    wrap_text=False,
)

STYLE_SECTION_LABEL = CellStyle(
    fill_color=AZUL_OSCURO,
    font_color=BLANCO,
    font_bold=True,
    font_size=8.0,
    font_name="Calibri",
    h_align="left",
    v_align="center",
    wrap_text=True,
)

STYLE_PROJECT_TITLE = CellStyle(
    fill_color=AZUL_CLARO,
    font_color=NEGRO,
    font_bold=True,
    font_size=10.0,
    font_name="Calibri",
    h_align="center",
    v_align="center",
    wrap_text=True,
)

STYLE_ELLIPSIS = CellStyle(
    fill_color=BLANCO,
    font_color=NEGRO,
    font_bold=False,
    font_size=9.0,
    font_name="Calibri",
    h_align="center",
    v_align="center",
    wrap_text=False,
)

STYLE_DEFAULT = CellStyle(
    fill_color=BLANCO,
    font_color=NEGRO,
    font_bold=False,
    font_size=9.0,
    font_name="Calibri",
    h_align="left",
    v_align="center",
    wrap_text=False,
)


# ── Dimensiones canónicas (en unidades openpyxl) ──────────────────────────────
ROW_HEIGHT_HEADER   = 18.0   # fila de años
ROW_HEIGHT_LABEL    = 15.0   # fila de etiqueta de fase
ROW_HEIGHT_SECTION  = 30.0   # fila de nombre de sección (puede ir en 2 líneas)
ROW_HEIGHT_DEFAULT  = 15.0

COL_WIDTH_YEAR      = 14.0   # columna que contiene un año
COL_WIDTH_ELLIPSIS  = 4.0    # columna "…"
COL_WIDTH_SECTION   = 22.0   # columna de etiqueta de sección
COL_WIDTH_DEFAULT   = 14.0


# ── PowerPoint (EMU: 1 pulgada = 914400 EMU) ─────────────────────────────────
PPTX_SLIDE_WIDTH_EMU  = 9144000   # 10 pulgadas
PPTX_SLIDE_HEIGHT_EMU = 5143500   # 5.63 pulgadas (widescreen 16:9)
PPTX_MARGIN_EMU       = 457200    # 0.5 pulgadas de margen
PPTX_YEAR_BAR_H_EMU   = 400000   # altura de la barra de años (~0.44")
PPTX_LABEL_BAR_H_EMU  = 340000   # altura de la banda de etiqueta


def apply_style(cell, style: CellStyle) -> None:
    """Aplica un CellStyle a una celda openpyxl."""
    cell.fill = PatternFill(
        fill_type="solid",
        fgColor=style.fill_color,
    )
    cell.font = Font(
        name=style.font_name,
        size=style.font_size,
        bold=style.font_bold,
        color=style.font_color,
    )
    cell.alignment = Alignment(
        horizontal=style.h_align,
        vertical=style.v_align,
        wrap_text=style.wrap_text,
    )


def thin_border() -> Border:
    thin = Side(style="thin", color="BFBFBF")
    return Border(left=thin, right=thin, top=thin, bottom=thin)
