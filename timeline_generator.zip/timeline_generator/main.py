"""
main.py
Punto de entrada de Timeline Generator.
"""

import logging
import sys
from pathlib import Path

# Asegurar que los módulos locales sean encontrables
sys.path.insert(0, str(Path(__file__).parent))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)

from gui.app_window import AppWindow


def main():
    app = AppWindow()
    app.mainloop()


if __name__ == "__main__":
    main()
