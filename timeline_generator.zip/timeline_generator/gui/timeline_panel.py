"""
timeline_panel.py
Panel reutilizable para cada "Timeline N".
Maneja la carga de archivos, muestra su estado y permite eliminarlos.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Callable, Optional

import customtkinter as ctk
from tkinter import filedialog


SUPPORTED_EXTENSIONS = (
    ("Archivos soportados", "*.xlsx *.xls *.docx *.pdf *.png *.jpg *.jpeg"),
    ("Excel", "*.xlsx *.xls"),
    ("Word", "*.docx"),
    ("PDF", "*.pdf"),
    ("Imagen", "*.png *.jpg *.jpeg"),
    ("Todos", "*.*"),
)

# Íconos de estado (texto, sin dependencias externas)
ICON_OK      = "✓"
ICON_WARN    = "⚠"
ICON_REMOVE  = "✕"


class FileRow(ctk.CTkFrame):
    """Fila que muestra un archivo cargado con su estado y botón de eliminar."""

    def __init__(self, parent, filepath: Path, on_remove: Callable):
        super().__init__(parent, fg_color="transparent")
        self.filepath  = filepath
        self.on_remove = on_remove
        self._build()

    def _build(self):
        self.grid_columnconfigure(1, weight=1)

        # Ícono de tipo
        ext   = self.filepath.suffix.lower()
        icons = {".xlsx": "📊", ".xls": "📊", ".docx": "📄", ".pdf": "📕",
                 ".png": "🖼", ".jpg": "🖼", ".jpeg": "🖼"}
        icon_label = ctk.CTkLabel(self, text=icons.get(ext, "📎"), width=24)
        icon_label.grid(row=0, column=0, padx=(4, 2))

        # Nombre del archivo
        name_label = ctk.CTkLabel(
            self,
            text=self.filepath.name,
            anchor="w",
            font=ctk.CTkFont(size=12),
        )
        name_label.grid(row=0, column=1, sticky="ew", padx=4)

        # Tamaño del archivo
        try:
            size_kb = self.filepath.stat().st_size // 1024
            size_txt = f"{size_kb} KB" if size_kb > 0 else "< 1 KB"
        except Exception:
            size_txt = ""
        ctk.CTkLabel(self, text=size_txt, width=60, text_color="gray").grid(row=0, column=2, padx=4)

        # Estado
        self._status_var = ctk.StringVar(value=f"{ICON_OK} Listo")
        ctk.CTkLabel(self, textvariable=self._status_var, width=80, text_color="#1a7a1a").grid(row=0, column=3, padx=4)

        # Botón eliminar
        ctk.CTkButton(
            self,
            text=ICON_REMOVE, width=28, height=24,
            fg_color="transparent", text_color="gray",
            hover_color="#ffdddd",
            command=lambda: self.on_remove(self),
        ).grid(row=0, column=4, padx=(2, 4))

    def set_status(self, text: str, ok: bool = True):
        icon = ICON_OK if ok else ICON_WARN
        self._status_var.set(f"{icon} {text}")


class TimelinePanel(ctk.CTkFrame):
    """
    Panel para un único 'Timeline N'.
    Contiene: título, lista de archivos, botón 'Seleccionar Archivos', botón eliminar panel.
    """

    def __init__(
        self,
        parent,
        title: str = "Timeline 1",
        on_remove: Optional[Callable] = None,
    ):
        super().__init__(parent, border_width=1, border_color="#cccccc")
        self.title    = title
        self.on_remove = on_remove
        self._files: list[Path]    = []
        self._rows:  list[FileRow] = []
        self._build()

    # ── Construcción ──────────────────────────────────────────────────────────

    def _build(self):
        self.grid_columnconfigure(0, weight=1)

        # Cabecera
        header = ctk.CTkFrame(self, fg_color="#1F497D", corner_radius=6)
        header.grid(row=0, column=0, sticky="ew", padx=0, pady=0)
        header.grid_columnconfigure(0, weight=1)

        self._title_label = ctk.CTkLabel(
            header, text=self.title,
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color="white", anchor="w",
        )
        self._title_label.grid(row=0, column=0, sticky="ew", padx=10, pady=6)

        if self.on_remove:
            ctk.CTkButton(
                header,
                text="Eliminar panel", width=110, height=26,
                fg_color="transparent", text_color="#aaccff",
                hover_color="#163a66",
                command=lambda: self.on_remove(self),
            ).grid(row=0, column=1, padx=6)

        # Área de archivos
        self._files_frame = ctk.CTkFrame(self, fg_color="transparent")
        self._files_frame.grid(row=1, column=0, sticky="ew", padx=8, pady=4)
        self._files_frame.grid_columnconfigure(0, weight=1)

        # Mensaje placeholder
        self._placeholder = ctk.CTkLabel(
            self._files_frame,
            text="Sin archivos. Haz clic en 'Seleccionar Archivos'.",
            text_color="gray", font=ctk.CTkFont(size=11, slant="italic"),
        )
        self._placeholder.grid(row=0, column=0, pady=8)

        # Botón seleccionar
        ctk.CTkButton(
            self,
            text="Seleccionar Archivos",
            width=160, height=30,
            command=self._select_files,
        ).grid(row=2, column=0, pady=(0, 8))

    # ── Gestión de archivos ───────────────────────────────────────────────────

    def _select_files(self):
        paths = filedialog.askopenfilenames(
            title=f"Seleccionar archivos para {self.title}",
            filetypes=SUPPORTED_EXTENSIONS,
        )
        for p in paths:
            self._add_file(Path(p))

    def _add_file(self, path: Path):
        if path in self._files:
            return  # ya existe

        self._files.append(path)

        # Ocultar placeholder si hay archivos
        if len(self._files) == 1:
            self._placeholder.grid_remove()

        row = FileRow(
            self._files_frame,
            filepath=path,
            on_remove=self._remove_file_row,
        )
        row.grid(row=len(self._rows), column=0, sticky="ew", pady=2)
        self._rows.append(row)

    def _remove_file_row(self, row: FileRow):
        if row.filepath in self._files:
            self._files.remove(row.filepath)
        if row in self._rows:
            self._rows.remove(row)
        row.destroy()

        # Mostrar placeholder si no hay archivos
        if not self._files:
            self._placeholder.grid()

        # Re-numerar filas
        for i, r in enumerate(self._rows):
            r.grid(row=i, column=0, sticky="ew", pady=2)

    # ── API pública ───────────────────────────────────────────────────────────

    def get_files(self) -> list[Path]:
        return list(self._files)

    def set_title(self, title: str):
        self.title = title
        self._title_label.configure(text=title)
