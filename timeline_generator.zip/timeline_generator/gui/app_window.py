"""
app_window.py
Ventana principal de la aplicación.
Diseño limpio y funcional — sin colores decorativos, sin dashboards.
Solo los controles necesarios.
"""

from __future__ import annotations

import logging
import threading
from pathlib import Path
from typing import Optional

import customtkinter as ctk

from gui.timeline_panel import TimelinePanel
from core.model_analyzer import ModelAnalyzer
from core.file_parser import FileParser
from core.timeline_builder import TimelineBuilder, BuilderConfig
from core.excel_generator import ExcelGenerator
from core.pptx_generator import PptxGenerator
from utils.date_detector import DetectorConfig

logger = logging.getLogger(__name__)

# Ruta al workbook modelo (relativa al main.py)
MODEL_PATH = Path(__file__).parent.parent / "assets" / "formato_excel_modelo.xlsx"


class AppWindow(ctk.CTk):
    """Ventana principal de Timeline Generator."""

    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")

        self.title("Timeline Generator – MIMP")
        self.geometry("820x680")
        self.resizable(True, True)
        self.minsize(700, 500)

        self._panels: list[TimelinePanel] = []
        self._template = None

        self._build_ui()
        self._load_template()

    # ── Construcción de la UI ─────────────────────────────────────────────────

    def _build_ui(self):
        # Layout principal: scroll area + barra inferior fija
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        # ── Área scrollable de timelines ──────────────────────────────────────
        self._scroll_frame = ctk.CTkScrollableFrame(self, label_text="Timelines")
        self._scroll_frame.grid(row=0, column=0, sticky="nsew", padx=12, pady=(12, 4))
        self._scroll_frame.grid_columnconfigure(0, weight=1)

        # ── Barra inferior ────────────────────────────────────────────────────
        bottom = ctk.CTkFrame(self, fg_color="transparent")
        bottom.grid(row=1, column=0, sticky="ew", padx=12, pady=(4, 12))
        bottom.grid_columnconfigure(1, weight=1)

        # Botón + Agregar Timeline
        ctk.CTkButton(
            bottom, text="+ Agregar Timeline",
            width=160, command=self._add_timeline_panel,
        ).grid(row=0, column=0, padx=(0, 8))

        # Panel de opciones de salida
        options_frame = ctk.CTkFrame(bottom)
        options_frame.grid(row=0, column=1, sticky="ew", padx=4)

        ctk.CTkLabel(options_frame, text="Salida:").pack(side="left", padx=(8, 4))
        self._var_excel = ctk.BooleanVar(value=True)
        self._var_pptx  = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(options_frame, text="Excel (.xlsx)", variable=self._var_excel).pack(side="left", padx=4)
        ctk.CTkCheckBox(options_frame, text="PowerPoint (.pptx)", variable=self._var_pptx).pack(side="left", padx=4)

        # Granularidad
        ctk.CTkLabel(options_frame, text="  Granularidad:").pack(side="left", padx=(12, 4))
        self._var_gran = ctk.StringVar(value="Anual")
        ctk.CTkOptionMenu(
            options_frame,
            variable=self._var_gran,
            values=["Anual", "Mensual"],
            width=90,
        ).pack(side="left", padx=4)

        # Umbral de síntesis
        ctk.CTkLabel(options_frame, text="  Máx columnas:").pack(side="left", padx=(12, 4))
        self._var_max_cols = ctk.StringVar(value="14")
        ctk.CTkEntry(options_frame, textvariable=self._var_max_cols, width=45).pack(side="left", padx=(0, 8))

        # Botón Generar
        ctk.CTkButton(
            bottom, text="Generar Timelines",
            width=160, fg_color="#1F497D", hover_color="#163a66",
            command=self._on_generate,
        ).grid(row=0, column=2, padx=(8, 0))

        # Barra de estado
        self._status_var = ctk.StringVar(value="Listo.")
        ctk.CTkLabel(self, textvariable=self._status_var, anchor="w").grid(
            row=2, column=0, sticky="ew", padx=16, pady=(0, 6)
        )

        # Panel inicial
        self._add_timeline_panel()

    # ── Paneles de timeline ───────────────────────────────────────────────────

    def _add_timeline_panel(self):
        idx   = len(self._panels) + 1
        panel = TimelinePanel(
            self._scroll_frame,
            title=f"Timeline {idx}",
            on_remove=lambda p=None: self._remove_panel(p),
        )
        panel.grid(
            row=idx - 1, column=0,
            sticky="ew", padx=4, pady=4,
        )
        self._panels.append(panel)

    def _remove_panel(self, panel: Optional[TimelinePanel] = None):
        if panel and panel in self._panels:
            self._panels.remove(panel)
            panel.destroy()
        elif self._panels:
            p = self._panels.pop()
            p.destroy()
        # Renumerar
        for i, p in enumerate(self._panels, 1):
            p.set_title(f"Timeline {i}")

    # ── Carga del template ────────────────────────────────────────────────────

    def _load_template(self):
        def _load():
            try:
                analyzer = ModelAnalyzer(MODEL_PATH)
                self._template = analyzer.extract()
                self._set_status("Template cargado correctamente.")
            except Exception as e:
                self._set_status(f"⚠ Error cargando template: {e}")
                logger.exception("Error cargando template")

        threading.Thread(target=_load, daemon=True).start()

    # ── Generación ────────────────────────────────────────────────────────────

    def _on_generate(self):
        if not self._template:
            self._show_error("El template del modelo aún no está cargado. Espera un momento.")
            return

        files = []
        for panel in self._panels:
            panel_files = panel.get_files()
            if panel_files:
                files.append((panel.title, panel_files))

        if not files:
            self._show_error("No hay archivos cargados. Agrega al menos un archivo.")
            return

        if not self._var_excel.get() and not self._var_pptx.get():
            self._show_error("Selecciona al menos un formato de salida (Excel o PowerPoint).")
            return

        # Lanzar en hilo para no bloquear la UI
        threading.Thread(target=self._run_generation, args=(files,), daemon=True).start()

    def _run_generation(self, files: list[tuple[str, list[Path]]]):
        self._set_status("Procesando…")
        try:
            gran     = "monthly" if self._var_gran.get() == "Mensual" else "annual"
            max_cols = int(self._var_max_cols.get() or 14)

            detect_cfg = DetectorConfig(granularity=gran)
            build_cfg  = BuilderConfig(granularity=gran, max_columns=max_cols)

            parser  = FileParser(detect_cfg)
            builder = TimelineBuilder(build_cfg)

            layouts     = []
            all_warnings = []

            for timeline_idx, (panel_title, panel_files) in enumerate(files):
                for filepath in panel_files:
                    self._set_status(f"Parseando: {filepath.name}…")
                    try:
                        parsed = parser.parse(filepath)
                        layout = builder.build(parsed, timeline_index=timeline_idx)
                        layouts.append(layout)
                        all_warnings.extend(layout.warnings)
                    except Exception as e:
                        logger.exception("Error procesando %s", filepath)
                        all_warnings.append(
                            type("W", (), {"message": f"{filepath.name}: {e}", "events_compressed": 0})()
                        )

            if not layouts:
                self._set_status("⚠ No se generó ningún layout. Revisa los archivos.")
                return

            # Mostrar advertencias de síntesis si las hay
            if all_warnings:
                compressed = [w for w in all_warnings if w.events_compressed > 0]
                if compressed:
                    msg = "\n".join(f"• {w.message}" for w in compressed)
                    proceed = self._ask_warnings(
                        f"Se comprimieron eventos en {len(compressed)} sección(s):\n\n{msg}\n\n"
                        "¿Deseas continuar con la generación?"
                    )
                    if not proceed:
                        self._set_status("Generación cancelada por el usuario.")
                        return

            # Previsualizacion de eventos
            preview_lines = []
            for layout in layouts:
                preview_lines.append(f"\n► {layout.project_title}")
                for section in layout.sections:
                    labels = " | ".join(c.label for c in section.columns)
                    preview_lines.append(f"   [{section.title}] {labels}")

            proceed = self._ask_preview(
                "Eventos detectados por archivo:\n" + "\n".join(preview_lines) +
                "\n\n¿Confirmar generación?"
            )
            if not proceed:
                self._set_status("Generación cancelada.")
                return

            # Generar archivos
            output_dir = Path("output")
            output_dir.mkdir(exist_ok=True)

            if self._var_excel.get():
                self._set_status("Generando Excel…")
                gen = ExcelGenerator(self._template)
                for layout in layouts:
                    gen.add_layout(layout)
                out_path = gen.save(output_dir / "timelines.xlsx")
                self._set_status(f"Excel guardado: {out_path}")

            if self._var_pptx.get():
                self._set_status("Generando PowerPoint…")
                gen = PptxGenerator(self._template)
                for layout in layouts:
                    gen.add_layout(layout)
                out_path = gen.save(output_dir / "timelines.pptx")
                self._set_status(f"PowerPoint guardado: {out_path}")

            self._set_status(
                f"✓ Generación completada. {len(layouts)} timeline(s) → carpeta 'output/'."
            )

        except Exception as e:
            logger.exception("Error durante la generación")
            self._set_status(f"✗ Error: {e}")

    # ── Helpers de UI ─────────────────────────────────────────────────────────

    def _set_status(self, msg: str):
        """Actualiza la barra de estado (thread-safe)."""
        self.after(0, lambda: self._status_var.set(msg))

    def _show_error(self, msg: str):
        from tkinter import messagebox
        messagebox.showerror("Error", msg, parent=self)

    def _ask_warnings(self, msg: str) -> bool:
        from tkinter import messagebox
        result = [False]
        def _ask():
            result[0] = messagebox.askyesno("Advertencia de síntesis", msg, parent=self)
        self.after(0, _ask)
        # Esperar resultado (bloqueo ligero en hilo)
        import time
        for _ in range(100):
            time.sleep(0.05)
            if result[0] is not False:
                break
        return result[0]

    def _ask_preview(self, msg: str) -> bool:
        from tkinter import messagebox
        result = [None]
        def _ask():
            result[0] = messagebox.askyesno("Vista previa de eventos", msg, parent=self)
        self.after(0, _ask)
        import time
        for _ in range(200):
            time.sleep(0.05)
            if result[0] is not None:
                break
        return bool(result[0])
