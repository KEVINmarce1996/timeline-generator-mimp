# Timeline Generator — MIMP

Genera líneas de tiempo profesionales en Excel y PowerPoint a partir de documentos del SEACE, cronogramas, imágenes y archivos Word.

## Características

- **Formatos de entrada**: `.xlsx`, `.docx`, `.pdf`, `.png`, `.jpg`
- **Salidas**: Excel (`.xlsx`) y PowerPoint (`.pptx`)
- **Colores inteligentes por estado**:
  - 🔘 Gris — Ejecutado (fecha ya pasó)
  - 🔵 Azul — En curso (próximo evento)
  - 🟡 Amarillo — Pendiente (fecha futura)
- **Especializado en tablas SEACE** (Etapa / Fecha Inicio / Fecha Fin)
- **Visión con Gemini 2.5 Flash** para leer imágenes y DOCX con capturas

## Instalación

```bash
git clone https://github.com/tu-usuario/timeline-generator.git
cd timeline-generator
pip install -r requirements.txt
```

## Uso local (con GUI)

```bash
python main.py
```

## Uso en Google Colab

1. Abre `timeline_generator_colab.ipynb` en Colab
2. Ejecuta todas las celdas (`Ctrl+F9`)
3. Sube `timeline_generator_v2.zip` cuando se pida
4. Sube tus archivos de cronograma
5. Descarga el Excel y PowerPoint generados

## Configurar Gemini Vision (para imágenes)

**En Colab**: Panel izquierdo → 🔑 Secrets → activar `GOOGLE_API_KEY`

**En local**:
```bash
export GOOGLE_API_KEY=tu_clave_aqui
```

## Estructura del proyecto

```
timeline_generator/
├── main.py                     # GUI de escritorio
├── requirements.txt
├── assets/
│   └── formato_excel_modelo.xlsx  # Plantilla visual de referencia
├── core/
│   ├── model_analyzer.py       # Extrae template del modelo Excel
│   ├── file_parser.py          # Lee xlsx, docx, pdf, imágenes
│   ├── timeline_builder.py     # Construye layout + asigna colores
│   ├── excel_generator.py      # Genera .xlsx
│   └── pptx_generator.py       # Genera .pptx
├── gui/
│   ├── app_window.py           # Ventana principal
│   └── timeline_panel.py       # Panel por cada timeline
└── utils/
    ├── color_mapper.py         # Paleta y estilos del modelo
    ├── date_detector.py        # Detección de fechas en texto
    └── vision_parser.py        # Gemini Vision para imágenes
```

## Módulos principales

| Módulo | Responsabilidad |
|--------|----------------|
| `model_analyzer.py` | Lee la plantilla y extrae colores, fuentes, dimensiones |
| `file_parser.py` | Parsea cualquier formato → lista de eventos normalizados |
| `timeline_builder.py` | Agrupa por año, ordena por fecha, asigna estado de color |
| `excel_generator.py` | Genera hoja Excel con Drawing XML (rectángulos + conectores) |
| `pptx_generator.py` | Genera slide con shapes editables |
| `vision_parser.py` | Llama a Gemini 2.5 Flash para extraer datos de imágenes |
