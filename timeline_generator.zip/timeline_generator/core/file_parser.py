"""
file_parser.py
Extrae eventos cronológicos desde múltiples formatos de archivo.
Siempre devuelve una lista de TimelineEvent normalizada,
independientemente del formato de entrada.

Formatos soportados:
  .xlsx / .xls   → openpyxl / pandas
  .docx          → python-docx
  .pdf           → pdfplumber
  .png .jpg .jpeg → OCR con pytesseract (si está instalado) o texto alt
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from utils.date_detector import DateDetector, DetectedDate, DateGranularity, DetectorConfig

logger = logging.getLogger(__name__)


# ── Estructura de evento normalizado ─────────────────────────────────────────

@dataclass
class TimelineEvent:
    """
    Unidad mínima de información de una timeline.
    El generador solo consume esta estructura, no el archivo original.
    """
    label: str                        # Texto del evento/hito/etiqueta
    detected_date: Optional[DetectedDate] = None
    phase: str = ""                   # Fase o sección a la que pertenece
    source_file: str = ""             # Nombre del archivo de origen
    raw_value: str = ""               # Valor crudo antes de parseo
    is_section_header: bool = False   # True si es encabezado de sección
    status: str = "pending"            # "done" | "active" | "pending"

    @property
    def year(self) -> Optional[int]:
        return self.detected_date.year if self.detected_date else None

    @property
    def sort_key(self):
        """Para ordenar cronológicamente. Eventos sin fecha van al final."""
        if self.detected_date and self.detected_date.date_start:
            return self.detected_date.date_start
        from datetime import datetime
        return datetime.max


# ── Resultado del parser ──────────────────────────────────────────────────────

@dataclass
class ParseResult:
    events: list[TimelineEvent]
    project_title: str = ""
    source_file: str = ""
    warnings: list[str] = field(default_factory=list)

    @property
    def has_events(self) -> bool:
        return len(self.events) > 0

    @property
    def date_range(self) -> tuple[Optional[int], Optional[int]]:
        years = [e.year for e in self.events if e.year is not None]
        return (min(years), max(years)) if years else (None, None)


# ── Parser principal ──────────────────────────────────────────────────────────

class FileParser:
    """
    Facade que despacha al parser correcto según la extensión.

    Uso:
        parser = FileParser(DetectorConfig(granularity="annual"))
        result = parser.parse("mi_proyecto.xlsx")
        for event in result.events:
            print(event.year, event.label)
    """

    _SUPPORTED = {".xlsx", ".xls", ".docx", ".pdf", ".png", ".jpg", ".jpeg"}

    # Extensiones donde Vision siempre es el método principal
    _VISION_PRIMARY = {".png", ".jpg", ".jpeg"}
    # Extensiones donde Vision complementa al parser de texto
    _VISION_COMPLEMENT = {".docx", ".pdf"}

    def __init__(self, config: Optional[DetectorConfig] = None, use_vision: bool = True):
        """
        Args:
            config:      Configuración de detección de fechas.
            use_vision:  Si True (default), activa Gemini Vision cuando hay
                         imágenes o PDFs escaneados. Si la API key no está
                         disponible, se desactiva automáticamente sin error.
        """
        self.config    = config or DetectorConfig()
        self.detector  = DateDetector(self.config)
        self._vision   = None   # lazy init

        if use_vision:
            self._init_vision()

    def _init_vision(self) -> None:
        """Inicializa VisionParser. Si no hay API key, lo desactiva silenciosamente."""
        try:
            from utils.vision_parser import VisionParser
            vp = VisionParser()
            if vp.is_available:
                self._vision = vp
                logger.info("Gemini Vision activado (gemini-2.5-flash).")
            else:
                logger.info("GOOGLE_API_KEY no encontrada. Vision desactivado.")
        except Exception as e:
            logger.debug("Vision no disponible: %s", e)

    @property
    def vision_active(self) -> bool:
        return self._vision is not None

    def parse(self, filepath: str | Path) -> ParseResult:
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"Archivo no encontrado: {path}")

        ext = path.suffix.lower()
        if ext not in self._SUPPORTED:
            raise ValueError(f"Formato no soportado: {ext}. Soportados: {self._SUPPORTED}")

        logger.info("Parseando archivo: %s (%s)", path.name, ext)

        dispatch = {
            ".xlsx": self._parse_excel,
            ".xls":  self._parse_excel,
            ".docx": self._parse_docx,
            ".pdf":  self._parse_pdf,
            ".png":  self._parse_image,
            ".jpg":  self._parse_image,
            ".jpeg": self._parse_image,
        }
        result = dispatch[ext](path)
        result.source_file = path.name

        # ── Enriquecer con Gemini Vision si está disponible ───────────────────
        if self._vision:
            if ext in self._VISION_PRIMARY:
                # Imagen: Vision es el método principal, reemplazar resultado
                self._apply_vision_primary(result, path)
            elif ext in self._VISION_COMPLEMENT:
                # DOCX/PDF: Vision complementa el texto ya extraído
                self._apply_vision_complement(result, path)

        # Post-proceso: ordenar eventos cronológicamente
        result.events.sort(key=lambda e: e.sort_key)

        logger.info(
            "  → %d eventos detectados | rango: %s – %s",
            len(result.events),
            *result.date_range,
        )
        return result


    # Vision integration methods
    def _apply_vision_primary(self, result, path):
        """Imagenes: Vision es el metodo principal, reemplaza OCR basico."""
        from utils.vision_parser import enrich_with_vision as enrich_parse_result_with_vision
        result.events.clear()
        try:
            enrich_parse_result_with_vision(result, path, self._vision, self.config)
            logger.info("Vision (primario): %d eventos de %s", len(result.events), path.name)
        except Exception as e:
            logger.warning("Vision fallo en %s: %s", path.name, e)
            result.warnings.append(f"Vision no disponible para {path.name}: {e}")

    def _apply_vision_complement(self, result, path):
        """DOCX/PDF: Vision complementa texto, procesa imagenes embebidas."""
        from utils.vision_parser import enrich_with_vision as enrich_parse_result_with_vision
        pre_count = len(result.events)
        try:
            enrich_parse_result_with_vision(result, path, self._vision, self.config)
            added = len(result.events) - pre_count
            if added > 0:
                logger.info("Vision (complemento): +%d eventos de %s", added, path.name)
        except Exception as e:
            logger.warning("Vision complemento fallo en %s: %s", path.name, e)
            result.warnings.append(f"Vision (imagenes) no disponible para {path.name}: {e}")

    # Excel────────────────────────────────────────────────────────────────

    def _parse_excel(self, path: Path) -> ParseResult:
        from openpyxl import load_workbook
        import pandas as pd

        result = ParseResult(events=[], source_file=path.name)

        try:
            wb = load_workbook(path, read_only=True, data_only=True)
        except Exception as e:
            # Fallback para .xls legado
            logger.warning("openpyxl falló en %s, intentando xlrd: %s", path.name, e)
            return self._parse_excel_legacy(path)

        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            current_phase = sheet_name

            for row in ws.iter_rows(values_only=True):
                for cell_val in row:
                    if cell_val is None:
                        continue
                    val = str(cell_val).strip()
                    if not val or val == "…":
                        continue

                    # ¿Es encabezado de sección?
                    if self._looks_like_section(val):
                        current_phase = val
                        result.events.append(TimelineEvent(
                            label=val,
                            phase=current_phase,
                            source_file=path.name,
                            raw_value=val,
                            is_section_header=True,
                        ))
                        if not result.project_title:
                            result.project_title = val
                        continue

                    # Detectar fecha
                    detected = self.detector.detect(val)
                    if detected.granularity != DateGranularity.UNKNOWN:
                        result.events.append(TimelineEvent(
                            label=detected.display_label(self.config),
                            detected_date=detected,
                            phase=current_phase,
                            source_file=path.name,
                            raw_value=val,
                        ))
                    else:
                        # Texto sin fecha → guardar como hito sin fecha
                        if len(val) > 3:
                            result.events.append(TimelineEvent(
                                label=val,
                                phase=current_phase,
                                source_file=path.name,
                                raw_value=val,
                            ))

        return result

    def _parse_excel_legacy(self, path: Path) -> ParseResult:
        import pandas as pd
        result = ParseResult(events=[], source_file=path.name)
        try:
            sheets = pd.read_excel(path, engine="xlrd", sheet_name=None, header=None)
            for sheet_name, df in sheets.items():
                for val in df.values.flatten():
                    if val is None or str(val).strip() in ("", "nan", "…"):
                        continue
                    val_str = str(val).strip()
                    detected = self.detector.detect(val_str)
                    result.events.append(TimelineEvent(
                        label=detected.display_label(self.config) if detected.granularity != DateGranularity.UNKNOWN else val_str,
                        detected_date=detected if detected.granularity != DateGranularity.UNKNOWN else None,
                        phase=sheet_name,
                        source_file=path.name,
                        raw_value=val_str,
                    ))
        except Exception as e:
            result.warnings.append(f"Error leyendo Excel legado: {e}")
        return result

    # ── Word ──────────────────────────────────────────────────────────────────

    def _parse_docx(self, path: Path) -> ParseResult:
        from docx import Document

        result = ParseResult(events=[], source_file=path.name)
        try:
            doc = Document(path)
        except Exception as e:
            result.warnings.append(f"No se pudo abrir el archivo Word: {e}")
            return result

        # Título del documento
        if doc.paragraphs and doc.paragraphs[0].text.strip():
            result.project_title = doc.paragraphs[0].text.strip()

        current_phase = "General"

        for para in doc.paragraphs:
            text = para.text.strip()
            if not text:
                continue

            # Encabezados como fases
            if para.style.name.startswith("Heading"):
                current_phase = text
                result.events.append(TimelineEvent(
                    label=text,
                    phase=current_phase,
                    source_file=path.name,
                    raw_value=text,
                    is_section_header=True,
                ))
                continue

            # Detectar todas las fechas en el párrafo
            all_dates = self.detector.detect_all(text)
            if all_dates:
                for d in all_dates:
                    result.events.append(TimelineEvent(
                        label=d.display_label(self.config),
                        detected_date=d,
                        phase=current_phase,
                        source_file=path.name,
                        raw_value=text,
                    ))
            else:
                # Párrafo sin fecha pero con contenido → hito sin fecha
                if len(text) > 5:
                    result.events.append(TimelineEvent(
                        label=text[:80],   # truncar si muy largo
                        phase=current_phase,
                        source_file=path.name,
                        raw_value=text,
                    ))

        # Tablas
        for table in doc.tables:
            for row in table.rows:
                row_texts = [c.text.strip() for c in row.cells if c.text.strip()]
                combined = " ".join(row_texts)
                dates = self.detector.detect_all(combined)
                for d in dates:
                    result.events.append(TimelineEvent(
                        label=d.display_label(self.config),
                        detected_date=d,
                        phase=current_phase,
                        source_file=path.name,
                        raw_value=combined,
                    ))

        return result

    # ── PDF ───────────────────────────────────────────────────────────────────

    def _parse_pdf(self, path: Path) -> ParseResult:
        result = ParseResult(events=[], source_file=path.name)
        try:
            import pdfplumber
        except ImportError:
            result.warnings.append("pdfplumber no instalado. Instala con: pip install pdfplumber")
            return result

        try:
            with pdfplumber.open(path) as pdf:
                result.project_title = f"PDF: {path.stem}"
                current_phase = "General"

                for page_num, page in enumerate(pdf.pages, 1):
                    text = page.extract_text() or ""
                    for line in text.splitlines():
                        line = line.strip()
                        if not line:
                            continue

                        if self._looks_like_section(line):
                            current_phase = line
                            result.events.append(TimelineEvent(
                                label=line,
                                phase=current_phase,
                                source_file=path.name,
                                raw_value=line,
                                is_section_header=True,
                            ))
                            continue

                        dates = self.detector.detect_all(line)
                        if dates:
                            for d in dates:
                                result.events.append(TimelineEvent(
                                    label=d.display_label(self.config),
                                    detected_date=d,
                                    phase=current_phase,
                                    source_file=path.name,
                                    raw_value=line,
                                ))
                        elif len(line) > 5:
                            result.events.append(TimelineEvent(
                                label=line[:80],
                                phase=current_phase,
                                source_file=path.name,
                                raw_value=line,
                            ))

                    # Tablas en PDF
                    for table in page.extract_tables():
                        for row in table:
                            row_text = " ".join(str(c) for c in row if c)
                            dates = self.detector.detect_all(row_text)
                            for d in dates:
                                result.events.append(TimelineEvent(
                                    label=d.display_label(self.config),
                                    detected_date=d,
                                    phase=current_phase,
                                    source_file=path.name,
                                    raw_value=row_text,
                                ))
        except Exception as e:
            result.warnings.append(f"Error leyendo PDF: {e}")

        return result

    # ── Imagen ────────────────────────────────────────────────────────────────

    def _parse_image(self, path: Path) -> ParseResult:
        result = ParseResult(events=[], source_file=path.name)
        try:
            import pytesseract
            from PIL import Image
            img = Image.open(path)
            text = pytesseract.image_to_string(img, lang="spa+eng")
            for line in text.splitlines():
                line = line.strip()
                if not line:
                    continue
                dates = self.detector.detect_all(line)
                for d in dates:
                    result.events.append(TimelineEvent(
                        label=d.display_label(self.config),
                        detected_date=d,
                        phase="OCR",
                        source_file=path.name,
                        raw_value=line,
                    ))
        except ImportError:
            result.warnings.append(
                "pytesseract no disponible. Instala tesseract-ocr y pytesseract para procesar imágenes."
            )
        except Exception as e:
            result.warnings.append(f"Error procesando imagen: {e}")

        return result

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _looks_like_section(text: str) -> bool:
        keywords = [
            "saldo de obra", "proceso de selección", "proceso de seleccion",
            "ejecución", "ejecucion", "adquisición", "adquisicion",
            "fase", "etapa", "hito", "actividad", "componente",
        ]
        tl = text.lower()
        return any(kw in tl for kw in keywords) and len(text) < 100


# ── Test rápido ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    import sys
    if len(sys.argv) > 1:
        parser = FileParser(DetectorConfig(granularity="annual"))
        result = parser.parse(sys.argv[1])
        print(f"\nProyecto: {result.project_title}")
        print(f"Eventos ({len(result.events)}):")
        for e in result.events:
            print(f"  [{e.year or '????'}] {e.label}  (fase: {e.phase})")
        if result.warnings:
            print("\nAdvertencias:")
            for w in result.warnings:
                print(f"  ⚠ {w}")
    else:
        print("Uso: python file_parser.py <archivo>")
