"""
pptx_generator.py  v8

Layout en el TERCIO SUPERIOR del slide (≈35%).
UNA SOLA FILA de hitos encima de la barra.
Conectores rojos con círculo oval via XML nativo.
Leyenda en una línea horizontal.
"""
from __future__ import annotations
import logging
from datetime import date
from pathlib import Path
from lxml import etree
from pptx import Presentation
from pptx.util import Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN

from core.model_analyzer import TimelineTemplate
from core.timeline_builder import LayoutResult, TimelineSection, DONE, ACTIVE, PENDING

logger = logging.getLogger(__name__)

# ── Colores ───────────────────────────────────────────────────────────────────
C_DONE    = "B8B8B8"; F_DONE    = "FFFFFF"
C_ACTIVE  = "1F497D"; F_ACTIVE  = "FFFFFF"
C_PENDING = "F3EAAB"; F_PENDING = "333333"

# ── Dimensiones (EMU) — todo en el tercio superior ───────────────────────────
SW, SH      = 9144000, 5143500
MARGIN_H    = 360000
MARGIN_V    = 120000

TITLE_H     = 280000   # banda título
GAP_TITLE   = 50000    # título → hitos

HITO_W      = 820000   # ancho hito
HITO_H      = 350000   # alto hito (permite 3 líneas a 5.5pt)
CONN_H      = 220000   # conector vertical
YEAR_BAR_H  = 300000   # barra de años
LABEL_BAR_H = 260000   # banda etiqueta fase
GAP_LEGEND  = 140000   # etiqueta → leyenda
LEGEND_H    = 250000   # alto leyenda

HITO_PADDING = 460000  # padding horizontal dentro de columna
CONN_W_EMU   = 12700   # grosor conector (1pt)

# Posiciones Y calculadas una sola vez
_Y_TITLE  = MARGIN_V
_Y_HITOS  = _Y_TITLE + TITLE_H + GAP_TITLE        # 0.492"
_Y_BAR    = _Y_HITOS + HITO_H + CONN_H            # 0.995"
_Y_LABEL  = _Y_BAR   + YEAR_BAR_H                 # 1.323"
_Y_LEGEND = _Y_LABEL + LABEL_BAR_H + GAP_LEGEND   # 1.761"


def _rgb(h):
    return RGBColor(int(h[:2],16), int(h[2:4],16), int(h[4:],16))


class PptxGenerator:

    def __init__(self, template: TimelineTemplate):
        self.t     = template
        self.prs   = Presentation()
        self.prs.slide_width  = SW
        self.prs.slide_height = SH
        self._n    = 0
        self._today = date.today()

    def add_layout(self, layout: LayoutResult) -> None:
        slide = self.prs.slides.add_slide(self.prs.slide_layouts[6])
        self._n += 1
        self._render(slide, layout)
        logger.info("Slide %d: %s", self._n, layout.project_title[:50])

    def save(self, path) -> Path:
        out = Path(path)
        out.parent.mkdir(parents=True, exist_ok=True)
        self.prs.save(out)
        logger.info("PPTX: %s (%d slides)", out, self._n)
        return out

    # ── Render ────────────────────────────────────────────────────────────────

    def _render(self, slide, layout: LayoutResult):
        usable_w = SW - 2 * MARGIN_H

        # Título
        self._rect(slide, MARGIN_H, _Y_TITLE, usable_w, TITLE_H,
                   self.t.color_label_bg, self.t.color_label_fg,
                   layout.project_title, Pt(9), bold=True)

        for section in layout.sections:
            self._render_section(slide, section, usable_w)

        self._render_legend(slide)

    def _render_section(self, slide, section: TimelineSection, usable_w: int):
        cols = section.columns
        if not cols:
            return

        col_widths = self._col_widths(cols, usable_w)
        total_w    = sum(col_widths)

        # Barra de años
        x = MARGIN_H
        for i, col in enumerate(cols):
            w    = col_widths[i]
            fill = "E8E8E8" if col.is_ellipsis else self.t.color_year_bg
            fc   = "999999" if col.is_ellipsis else self.t.color_year_fg
            self._rect(slide, x, _Y_BAR, w, YEAR_BAR_H,
                       fill, fc, col.label, Pt(9), bold=not col.is_ellipsis)
            x += w

        # Banda de fase
        self._rect(slide, MARGIN_H, _Y_LABEL, total_w, LABEL_BAR_H,
                   self.t.color_label_bg, self.t.color_label_fg,
                   section.title, Pt(8.5), bold=True)

        # Hitos — UNA SOLA FILA arriba de la barra
        x = MARGIN_H
        for i, col in enumerate(cols):
            w = col_widths[i]
            if not col.is_ellipsis and col.events:
                centers = self._hito_centers(col, x, w)
                for e_idx, (event, cx) in enumerate(zip(col.events, centers)):
                    fill, fc = self._colors(event)
                    hx = cx - HITO_W // 2
                    hy = _Y_HITOS  # SIEMPRE en la misma fila

                    lines, fsize = self._label_and_font(event)
                    self._rounded_rect(slide, hx, hy, HITO_W, HITO_H, fill, fc,
                                       lines, font_size=fsize)

                    # Conector: desde bottom del hito hasta top de la barra
                    conn_y = hy + HITO_H
                    conn_h = _Y_BAR - conn_y
                    if conn_h > 5000:
                        self._connector(slide, cx, conn_y, conn_h)
            x += w

    # ── Leyenda (XML nativo) ──────────────────────────────────────────────────

    def _render_legend(self, slide):
        spTree = slide.shapes._spTree
        items = [
            ("F2F2F2", "444444", "Leyenda:",              680000),
            ("B8B8B8", "FFFFFF", "Ejecutado",             860000),
            ("1F497D", "FFFFFF", "En curso",              760000),
            ("F3EAAB", "333333", "Pendiente de ejecutar", 1750000),
        ]
        x = MARGIN_H; gap = 140000; sid = 90000
        for fill, fc, text, w in items:
            xml = (
                f'<p:sp xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"'
                f' xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
                f'<p:nvSpPr>'
                f'<p:cNvPr id="{sid}" name="leg_{sid}"/>'
                f'<p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr>'
                f'<p:nvPr/></p:nvSpPr>'
                f'<p:spPr>'
                f'<a:xfrm><a:off x="{x}" y="{_Y_LEGEND}"/>'
                f'<a:ext cx="{w}" cy="{LEGEND_H}"/></a:xfrm>'
                f'<a:prstGeom prst="roundRect"><a:avLst/></a:prstGeom>'
                f'<a:solidFill><a:srgbClr val="{fill}"/></a:solidFill>'
                f'<a:ln w="6350"><a:solidFill>'
                f'<a:srgbClr val="BBBBBB"/></a:solidFill></a:ln>'
                f'</p:spPr>'
                f'<p:txBody>'
                f'<a:bodyPr anchor="ctr" anchorCtr="1"><a:normAutofit/></a:bodyPr>'
                f'<a:lstStyle/>'
                f'<a:p><a:pPr algn="ctr"/>'
                f'<a:r><a:rPr lang="es-PE" sz="800" b="1" dirty="0">'
                f'<a:solidFill><a:srgbClr val="{fc}"/></a:solidFill>'
                f'<a:latin typeface="{self.t.font_name}"/></a:rPr>'
                f'<a:t>{text}</a:t></a:r></a:p>'
                f'</p:txBody></p:sp>'
            )
            spTree.append(etree.fromstring(xml))
            x += w + gap
            sid += 1

    # ── Conector XML nativo ───────────────────────────────────────────────────

    def _connector(self, slide, cx: int, y_top: int, height: int):
        spTree = slide.shapes._spTree
        x = cx - CONN_W_EMU // 2
        xml = (
            f'<p:cxnSp xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"'
            f' xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
            f'<p:nvCxnSpPr>'
            f'<p:cNvPr id="9999" name="conn_red"/>'
            f'<p:cNvCxnSpPr/><p:nvPr/>'
            f'</p:nvCxnSpPr>'
            f'<p:spPr>'
            f'<a:xfrm><a:off x="{x}" y="{y_top}"/>'
            f'<a:ext cx="0" cy="{height}"/></a:xfrm>'
            f'<a:prstGeom prst="straightConnector1"><a:avLst/></a:prstGeom>'
            f'<a:ln w="{CONN_W_EMU}">'
            f'<a:solidFill><a:srgbClr val="FF0000"/></a:solidFill>'
            f'<a:tailEnd type="oval"/>'
            f'</a:ln></p:spPr>'
            f'<p:style>'
            f'<a:lnRef idx="1"><a:schemeClr val="accent1"/></a:lnRef>'
            f'<a:fillRef idx="0"><a:schemeClr val="accent1"/></a:fillRef>'
            f'<a:effectRef idx="0"><a:schemeClr val="accent1"/></a:effectRef>'
            f'<a:fontRef idx="minor"><a:schemeClr val="tx1"/></a:fontRef>'
            f'</p:style>'
            f'</p:cxnSp>'
        )
        spTree.append(etree.fromstring(xml))

    # ── Primitivas python-pptx ────────────────────────────────────────────────

    def _rect(self, slide, l, t, w, h, fill, fc, text, fs, bold=False):
        sh = slide.shapes.add_shape(1, int(l), int(t), int(w), int(h))
        sh.fill.solid(); sh.fill.fore_color.rgb = _rgb(fill)
        sh.line.fill.background()
        tf = sh.text_frame; tf.word_wrap = True
        p  = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
        run = p.add_run()
        run.text = text; run.font.bold = bold
        run.font.size = fs; run.font.color.rgb = _rgb(fc)
        run.font.name = self.t.font_name

    def _rounded_rect(self, slide, l, t, w, h, fill, fc, lines_or_text,
                       font_size: float = 7.0):
        sh = slide.shapes.add_shape(5, int(l), int(t), int(w), int(h))
        sh.fill.solid(); sh.fill.fore_color.rgb = _rgb(fill)
        sh.line.fill.background()
        tf = sh.text_frame; tf.word_wrap = True
        lines = lines_or_text if isinstance(lines_or_text, list)                 else (lines_or_text.split("\n") if lines_or_text else [""])
        for i, line in enumerate(lines):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.alignment = PP_ALIGN.CENTER
            run = p.add_run()
            run.text = line
            run.font.size      = Pt(font_size)
            run.font.bold      = True
            run.font.color.rgb = _rgb(fc)
            run.font.name      = self.t.font_name

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _colors(self, event):
        s = getattr(event, "status", PENDING)
        if s == DONE:   return C_DONE,   F_DONE
        if s == ACTIVE: return C_ACTIVE, F_ACTIVE
        return C_PENDING, F_PENDING

    @staticmethod
    def _clean_label(text: str) -> str:
        """Elimina sufijos SEACE redundantes para acortar etiquetas."""
        import re
        text = re.sub(r'\s*A TRAVES DEL SEACE\s*', '', text, flags=re.IGNORECASE)
        text = re.sub(r'\s*SEACE\s*$',             '', text, flags=re.IGNORECASE)
        text = re.sub(r'\(Electronica\)',          '(Elec.)', text, flags=re.IGNORECASE)
        text = re.sub(r'\s+y\s+observaciones',    ' y obs.', text, flags=re.IGNORECASE)
        return text.strip()

    @staticmethod
    def _optimal_font(text: str,
                      hito_w_emu: int = HITO_W,
                      hito_h_emu: int = HITO_H) -> tuple[float, list[str]]:
        """
        Elige el MAYOR font_size (8→7.5→7→6.5→6→5.5pt) tal que
        el texto quepa dentro del hito en máximo N líneas.
        N se calcula dinámicamente según la altura disponible.
        """
        PADDING_H, PADDING_V = 5, 3          # pt, padding interno
        avail_w = hito_w_emu / 914400 * 72 - 2 * PADDING_H
        avail_h = hito_h_emu / 914400 * 72 - 2 * PADDING_V

        for fs in (8.0, 7.5, 7.0, 6.5, 6.0, 5.5):
            cpl     = max(1, int(avail_w / (fs * 0.52)))
            max_l   = max(1, int(avail_h / (fs * 1.25)))
            words   = text.split()
            lines, cur = [], ""
            for w in words:
                test = (cur + " " + w).strip()
                if len(test) <= cpl:
                    cur = test
                else:
                    if cur: lines.append(cur)
                    cur = w
            if cur: lines.append(cur)
            if len(lines) <= max_l:
                return fs, lines

        # Fallback: forzar en 5.5pt máximo max_l líneas
        fs    = 5.5
        cpl   = max(1, int(avail_w / (fs * 0.52)))
        max_l = max(1, int(avail_h / (fs * 1.25)))
        words = text.split(); lines, cur = [], ""
        for w in words:
            test = (cur + " " + w).strip()
            if len(test) <= cpl: cur = test
            else:
                if cur: lines.append(cur)
                if len(lines) >= max_l: break
                cur = w
        if cur and len(lines) < max_l: lines.append(cur)
        return 5.5, lines

    def _label_and_font(self, event) -> tuple[list[str], float]:
        """Retorna (líneas_de_texto, font_size) para el hito."""
        raw   = self._clean_label(event.label)
        fsize, lines = self._optimal_font(raw, HITO_W, HITO_H)
        # Añadir fecha si hay espacio disponible
        PADDING_V = 3
        avail_h   = HITO_H / 914400 * 72 - 2 * PADDING_V
        max_l     = max(1, int(avail_h / (fsize * 1.25)))
        if event.detected_date and event.detected_date.date_start:
            d = event.detected_date.date_start
            if len(lines) < max_l:
                lines.append(f"{d.day:02d}/{d.month:02d}")
        return lines, fsize

    @staticmethod
    def _hito_centers(col, x_col: int, w_col: int) -> list[int]:
        n = len(col.events)
        if n == 1:
            return [x_col + w_col // 2]
        inner = w_col - 2 * HITO_PADDING
        step  = inner // (n - 1)
        step  = max(step, HITO_W + 40000)
        return [x_col + HITO_PADDING + j * step for j in range(n)]

    @staticmethod
    def _col_widths(cols, usable_w: int) -> list[int]:
        weights = [max(1.0, len(c.events)) if not c.is_ellipsis else 0.15
                   for c in cols]
        total = sum(weights)
        raw   = [int(usable_w * w / total) for w in weights]
        raw[-1] += usable_w - sum(raw)
        return raw
