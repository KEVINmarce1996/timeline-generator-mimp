"""
model_analyzer.py
Lee el workbook 'formato_excel_modelo.xlsx' y extrae la estructura visual
como un objeto TimelineTemplate reutilizable por los generadores.

Reglas de extracción:
- Se analiza TODAS las hojas para detectar patrones recurrentes.
- Los valores se normalizan: si más del 60% de las hojas coinciden en un
  atributo, ese atributo se toma como canónico del template.
- Se preservan los merge ranges relativos (offsets de fila/columna desde
  la fila de inicio de la timeline).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter, column_index_from_string

logger = logging.getLogger(__name__)


# ── Estructuras de datos ──────────────────────────────────────────────────────

@dataclass
class RowPattern:
    """Describe el rol semántico de una fila dentro de la timeline."""
    role: str           # "title" | "year_header" | "phase_label" | "section" | "empty"
    row_offset: int     # distancia desde la fila de inicio de la timeline (0-based)
    height: float
    merged_span: int    # número de columnas fusionadas (1 = sin merge)


@dataclass
class ColumnPattern:
    """Describe el tipo de una columna dentro del eje temporal."""
    col_offset: int     # offset desde la columna de inicio (0-based)
    col_type: str       # "year" | "ellipsis" | "section_label" | "empty"
    width: float


@dataclass
class TimelineTemplate:
    """
    Representación canónica del diseño extraído del workbook modelo.
    Es la única fuente de verdad que usan excel_generator y pptx_generator.
    """
    # Paleta de colores (RGB hex, 6 chars)
    color_year_bg: str
    color_year_fg: str
    color_label_bg: str
    color_label_fg: str
    color_title_bg: str
    color_title_fg: str

    # Fuentes
    font_name: str
    font_size_year: float
    font_size_label: float
    font_size_title: float

    # Filas canónicas (offsets relativos)
    row_title_offset: int       # fila del título del proyecto
    row_year_offset: int        # fila de cabecera de años
    row_label_offset: int       # fila de banda de etiqueta de fase

    # Alturas de fila
    height_title: float
    height_year: float
    height_label: float
    height_default: float

    # Ancho de columnas
    width_year_col: float
    width_ellipsis_col: float
    width_section_col: float

    # Estructura de secciones adicionales detectadas
    extra_sections: list[dict] = field(default_factory=list)

    # Nombre de las hojas analizadas (para trazabilidad)
    source_sheets: list[str] = field(default_factory=list)


# ── Analizador ────────────────────────────────────────────────────────────────

class ModelAnalyzer:
    """
    Analiza el workbook modelo y produce un TimelineTemplate.

    Uso:
        analyzer = ModelAnalyzer("assets/formato_excel_modelo.xlsx")
        template = analyzer.extract()
    """

    # Colores por defecto en caso de que la extracción falle parcialmente
    _FALLBACK_COLORS = {
        "year_bg":   "1F497D",
        "year_fg":   "FFFFFF",
        "label_bg":  "DCE6F2",
        "label_fg":  "000000",
        "title_bg":  "DCE6F2",
        "title_fg":  "000000",
    }

    def __init__(self, model_path: str | Path):
        self.model_path = Path(model_path)
        if not self.model_path.exists():
            raise FileNotFoundError(f"Workbook modelo no encontrado: {self.model_path}")
        self._wb = None
        self._template: Optional[TimelineTemplate] = None

    # ── API pública ───────────────────────────────────────────────────────────

    def extract(self) -> TimelineTemplate:
        """Retorna el TimelineTemplate. Cachea el resultado tras la primera llamada."""
        if self._template is not None:
            return self._template
        self._wb = load_workbook(self.model_path)
        self._template = self._build_template()
        logger.info(
            "Template extraído de %d hojas: %s",
            len(self._template.source_sheets),
            self._template.source_sheets,
        )
        return self._template

    # ── Construcción del template ─────────────────────────────────────────────

    def _build_template(self) -> TimelineTemplate:
        sheets_data = [self._analyze_sheet(name) for name in self._wb.sheetnames]
        # Filtra hojas que no tienen datos suficientes
        valid = [d for d in sheets_data if d is not None]
        if not valid:
            raise ValueError("No se encontraron hojas con estructura de timeline válida.")

        # Consenso por mayoría
        colors     = self._consensus_colors(valid)
        fonts      = self._consensus_fonts(valid)
        rows       = self._consensus_rows(valid)
        col_widths = self._consensus_col_widths(valid)

        return TimelineTemplate(
            color_year_bg    = colors["year_bg"],
            color_year_fg    = colors["year_fg"],
            color_label_bg   = colors["label_bg"],
            color_label_fg   = colors["label_fg"],
            color_title_bg   = colors["title_bg"],
            color_title_fg   = colors["title_fg"],
            font_name        = fonts["name"],
            font_size_year   = fonts["size_year"],
            font_size_label  = fonts["size_label"],
            font_size_title  = fonts["size_title"],
            row_title_offset = rows["title_offset"],
            row_year_offset  = rows["year_offset"],
            row_label_offset = rows["label_offset"],
            height_title     = rows["height_title"],
            height_year      = rows["height_year"],
            height_label     = rows["height_label"],
            height_default   = rows["height_default"],
            width_year_col   = col_widths["year"],
            width_ellipsis_col = col_widths["ellipsis"],
            width_section_col  = col_widths["section"],
            source_sheets    = [d["sheet_name"] for d in valid],
        )

    # ── Análisis por hoja ─────────────────────────────────────────────────────

    def _analyze_sheet(self, sheet_name: str) -> Optional[dict]:
        ws = self._wb[sheet_name]
        result = {"sheet_name": sheet_name}

        year_row = None
        label_row = None
        title_row = None

        for row_idx, row in enumerate(ws.iter_rows(), start=1):
            for cell in row:
                if cell.value is None:
                    continue

                val = str(cell.value).strip()
                fill_color = self._get_fill_color(cell)
                font_color = self._get_font_color(cell)
                font_size  = cell.font.size if cell.font and cell.font.size else 9.0
                font_name  = cell.font.name if cell.font and cell.font.name else "Calibri"

                # Detectar fila de años (valores numéricos con fondo azul oscuro)
                if self._is_year(val) and fill_color and fill_color != "00000000":
                    if year_row is None:
                        year_row = {
                            "row_idx": row_idx,
                            "fill_color": fill_color,
                            "font_color": font_color,
                            "font_size": font_size,
                            "font_name": font_name,
                            "height": ws.row_dimensions[row_idx].height or 15.0,
                        }

                # Detectar fila de etiqueta de fase (texto con fondo azul claro)
                elif self._is_phase_label(val) and fill_color:
                    if label_row is None:
                        label_row = {
                            "row_idx": row_idx,
                            "fill_color": fill_color,
                            "font_color": font_color,
                            "font_size": font_size,
                            "font_name": font_name,
                            "height": ws.row_dimensions[row_idx].height or 15.0,
                        }

                # Detectar fila de título (texto largo en fila 1 o fila con merge amplio)
                elif self._is_title(val, cell) and title_row is None:
                    title_row = {
                        "row_idx": row_idx,
                        "fill_color": fill_color,
                        "font_color": font_color,
                        "font_size": font_size,
                        "height": ws.row_dimensions[row_idx].height or 20.0,
                    }

        if year_row is None:
            logger.debug("Hoja '%s' omitida: sin fila de años detectada.", sheet_name)
            return None

        # Anchos de columna
        col_widths = self._extract_col_widths(ws)

        result.update({
            "year_row":  year_row,
            "label_row": label_row,
            "title_row": title_row,
            "col_widths": col_widths,
        })
        return result

    # ── Consenso entre hojas ──────────────────────────────────────────────────

    def _consensus_colors(self, data: list[dict]) -> dict:
        def majority(values):
            if not values:
                return None
            return max(set(values), key=values.count)

        year_bgs   = [d["year_row"]["fill_color"]  for d in data if d.get("year_row")]
        year_fgs   = [d["year_row"]["font_color"]  for d in data if d.get("year_row")]
        label_bgs  = [d["label_row"]["fill_color"] for d in data if d.get("label_row")]
        label_fgs  = [d["label_row"]["font_color"] for d in data if d.get("label_row")]
        title_bgs  = [d["title_row"]["fill_color"] for d in data if d.get("title_row")]
        title_fgs  = [d["title_row"]["font_color"] for d in data if d.get("title_row")]

        fb = self._FALLBACK_COLORS
        return {
            "year_bg":  majority(year_bgs)  or fb["year_bg"],
            "year_fg":  majority(year_fgs)  or fb["year_fg"],
            "label_bg": majority(label_bgs) or fb["label_bg"],
            "label_fg": majority(label_fgs) or fb["label_fg"],
            "title_bg": majority(title_bgs) or fb["title_bg"],
            "title_fg": majority(title_fgs) or fb["title_fg"],
        }

    def _consensus_fonts(self, data: list[dict]) -> dict:
        names  = [d["year_row"]["font_name"] for d in data if d.get("year_row")]
        sizes  = [d["year_row"]["font_size"] for d in data if d.get("year_row")]
        lsizes = [d["label_row"]["font_size"] for d in data if d.get("label_row")]
        tsizes = [d["title_row"]["font_size"] for d in data if d.get("title_row")]

        def majority(values, fallback):
            return max(set(values), key=values.count) if values else fallback

        return {
            "name":       majority(names, "Calibri"),
            "size_year":  majority(sizes, 9.0),
            "size_label": majority(lsizes, 8.0),
            "size_title": majority(tsizes, 10.0),
        }

    def _consensus_rows(self, data: list[dict]) -> dict:
        year_rows  = [d["year_row"]["row_idx"]  for d in data if d.get("year_row")]
        label_rows = [d["label_row"]["row_idx"] for d in data if d.get("label_row")]
        title_rows = [d["title_row"]["row_idx"] for d in data if d.get("title_row")]
        y_heights  = [d["year_row"]["height"]   for d in data if d.get("year_row")]
        l_heights  = [d["label_row"]["height"]  for d in data if d.get("label_row")]
        t_heights  = [d["title_row"]["height"]  for d in data if d.get("title_row")]

        def avg(vals, fallback):
            return round(sum(vals) / len(vals), 1) if vals else fallback

        def majority(values, fallback):
            return max(set(values), key=values.count) if values else fallback

        year_offset  = majority(year_rows, 9) - 1
        label_offset = majority(label_rows, 10) - 1 if label_rows else year_offset + 1
        title_offset = majority(title_rows, 1) - 1 if title_rows else 0

        return {
            "year_offset":   year_offset,
            "label_offset":  label_offset,
            "title_offset":  title_offset,
            "height_year":   avg(y_heights, 18.0),
            "height_label":  avg(l_heights, 15.0),
            "height_title":  avg(t_heights, 20.0),
            "height_default": 15.0,
        }

    def _consensus_col_widths(self, data: list[dict]) -> dict:
        year_widths  = []
        ellip_widths = []
        sec_widths   = []

        for d in data:
            cw = d.get("col_widths", {})
            year_widths.extend(cw.get("year", []))
            ellip_widths.extend(cw.get("ellipsis", []))
            sec_widths.extend(cw.get("section", []))

        def avg(vals, fallback):
            return round(sum(vals) / len(vals), 2) if vals else fallback

        return {
            "year":     avg(year_widths, 14.0),
            "ellipsis": avg(ellip_widths, 4.0),
            "section":  avg(sec_widths, 22.0),
        }

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _get_fill_color(cell) -> Optional[str]:
        try:
            rgb = cell.fill.fgColor.rgb
            # openpyxl devuelve "00000000" para sin relleno
            if isinstance(rgb, str) and len(rgb) >= 6:
                return rgb[-6:]  # strip alpha prefix si viene con 8 chars
        except Exception:
            pass
        return None

    @staticmethod
    def _get_font_color(cell) -> str:
        try:
            rgb = cell.font.color.rgb
            if isinstance(rgb, str) and len(rgb) >= 6:
                return rgb[-6:]
        except Exception:
            pass
        return "000000"

    @staticmethod
    def _is_year(value: str) -> bool:
        try:
            year = int(value)
            return 1900 <= year <= 2100
        except (ValueError, TypeError):
            return False

    @staticmethod
    def _is_phase_label(value: str) -> bool:
        keywords = [
            "linea de tiempo", "línea de tiempo",
            "proceso de selección", "proceso de seleccion",
            "ejecución contractual", "ejecucion contractual",
            "adquisición", "adquisicion",
        ]
        val_lower = value.lower()
        return any(kw in val_lower for kw in keywords)

    @staticmethod
    def _is_title(value: str, cell) -> bool:
        """Título: texto largo (>20 chars) en una celda fusionada o en fila 1."""
        if len(value) > 20:
            # Verificar que sea inicio de un merge o esté en fila 1
            return cell.row <= 3 or cell.column == 1
        return False

    def _extract_col_widths(self, ws) -> dict:
        """Clasifica los anchos de columna por tipo (year, ellipsis, section)."""
        result = {"year": [], "ellipsis": [], "section": []}
        for col_letter, col_dim in ws.column_dimensions.items():
            if col_dim.width is None:
                continue
            w = col_dim.width
            # Heurística basada en los anchos observados en el modelo
            if w <= 6.0:
                result["ellipsis"].append(w)
            elif w <= 18.0:
                result["year"].append(w)
            else:
                result["section"].append(w)
        return result


# ── Punto de entrada de prueba ────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    analyzer = ModelAnalyzer("../assets/formato_excel_modelo.xlsx")
    t = analyzer.extract()
    print("=== TEMPLATE EXTRAÍDO ===")
    for k, v in vars(t).items():
        print(f"  {k}: {v}")
