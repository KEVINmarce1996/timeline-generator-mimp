"""
excel_generator.py  v4

Replica exactamente el modelo SAN JUDAS:
  - Columnas = AÑOS, ancho proporcional a nº de hitos
  - Hitos distribuidos horizontalmente dentro del año, ordenados por fecha
  - Colores via schemeClr en Drawing XML para fidelidad máxima:
      DONE    → scheme:bg1 lumMod=75000  (gris como en leyenda del modelo)
      ACTIVE  → rgb:1F497D               (azul oscuro exacto del modelo)
      PENDING → rgb:F3EAAB               (amarillo exacto del modelo)
  - Leyenda al pie igual que el modelo
  - Conectores rojos con tailEnd oval
"""
from __future__ import annotations
import logging, shutil, zipfile
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter

from core.model_analyzer import TimelineTemplate
from core.timeline_builder import LayoutResult, DONE, ACTIVE, PENDING

logger = logging.getLogger(__name__)

NS_XDR = "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"
NS_A   = "http://schemas.openxmlformats.org/drawingml/2006/main"

# ── Layout de filas (1-indexed) ───────────────────────────────────────────────
ROW_TITLE   = 1
ROW_BAR     = 9    # barra de años
ROW_LABEL   = 10   # etiqueta de fase
ROWS_ABOVE  = list(range(2, 9))   # filas para hitos encima (2-8, 7 filas)
ROWS_BELOW  = list(range(11, 18)) # filas para hitos debajo (11-17, 7 filas)
ROW_LEGEND  = 20   # fila de leyenda

# ── Alturas ───────────────────────────────────────────────────────────────────
H_TITLE  = 24.0
H_ABOVE  = 15.75  # filas encima de la barra
H_BAR    = 16.5
H_LABEL  = 15.75
H_BELOW  = 15.75  # filas debajo de la barra

# ── Ancho de columna por hito (en unidades Excel) ────────────────────────────
WIDTH_PER_HITO = 14.0    # ancho mínimo por hito dentro de la columna
WIDTH_MIN      = 16.0    # mínimo absoluto por columna año
WIDTH_ELLIPSIS = 5.0

# ── EMU por unidad de col (~14pt) ─────────────────────────────────────────────
# 1 unidad de ancho de col en Excel ≈ 9144 EMU en drawing
EMU_PER_COL_UNIT = 9144

# Paso horizontal entre hitos dentro de una columna (en colOff EMU)
HITO_STEP_EMU = 1050000   # ~115 col units = misma escala que el modelo real
HITO_FIRST_EMU = 450000   # offset del primer hito desde el borde de la columna

# Tamaño del rectángulo de hito (igual que modelo)
HITO_CX = 876300
HITO_CY = 619582

COL_OFFSET = 2  # primera columna de datos = B (índice 2)


class ExcelGenerator:

    def __init__(self, template: TimelineTemplate, model_path=None):
        self.t          = template
        self.model_path = (Path(model_path) if model_path else
                           Path(__file__).parent.parent / "assets" /
                           "formato_excel_modelo.xlsx")
        self.wb         = Workbook()
        self.wb.remove(self.wb.active)
        self._sheets: list[dict] = []

    def add_layout(self, layout: LayoutResult) -> None:
        name = self._safe(layout.project_title)
        ws   = self.wb.create_sheet(title=name)
        self._write_cells(ws, layout)
        self._sheets.append({"name": name, "layout": layout,
                              "idx": len(self._sheets) + 1})
        logger.info("Hoja: %s", name)

    def save(self, output_path) -> Path:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        self.wb.save(out)
        self._inject_drawings(out)
        logger.info("Excel: %s", out)
        return out

    # ── Escritura de celdas ───────────────────────────────────────────────────

    def _write_cells(self, ws, layout: LayoutResult):
        t = self.t
        section = layout.sections[0] if layout.sections else None
        cols    = section.columns if section else []
        n_cols  = len(cols)
        end_col = COL_OFFSET + n_cols - 1 if n_cols else COL_OFFSET

        # ── Fila 1: título ────────────────────────────────────────────────────
        tc = ws.cell(row=ROW_TITLE, column=COL_OFFSET, value=layout.project_title)
        if n_cols > 1:
            ws.merge_cells(start_row=ROW_TITLE, start_column=COL_OFFSET,
                           end_row=ROW_TITLE, end_column=end_col)
        tc.fill      = PatternFill("solid", fgColor=t.color_label_bg)
        tc.font      = Font(name=t.font_name, size=t.font_size_title,
                            bold=True, color=t.color_label_fg)
        tc.alignment = Alignment(horizontal="center", vertical="center",
                                  wrap_text=True)
        ws.row_dimensions[ROW_TITLE].height = H_TITLE

        # Filas encima de la barra
        for r in ROWS_ABOVE:
            ws.row_dimensions[r].height = H_ABOVE

        # ── Fila 9: barra de años ─────────────────────────────────────────────
        for i, col in enumerate(cols):
            c_idx = COL_OFFSET + i
            cell  = ws.cell(row=ROW_BAR, column=c_idx, value=col.label)
            n_h   = len(col.events)
            # Ancho proporcional a nº de hitos
            col_w = max(WIDTH_MIN, n_h * WIDTH_PER_HITO) if not col.is_ellipsis \
                    else WIDTH_ELLIPSIS
            ws.column_dimensions[get_column_letter(c_idx)].width = col_w

            if col.is_ellipsis:
                cell.font      = Font(name=t.font_name, size=9, color="888888")
                cell.alignment = Alignment(horizontal="center", vertical="center")
            else:
                cell.fill      = PatternFill("solid", fgColor=t.color_year_bg)
                cell.font      = Font(name=t.font_name, size=t.font_size_year,
                                       bold=True, color=t.color_year_fg)
                cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[ROW_BAR].height = H_BAR

        # ── Fila 10: etiqueta de fase ─────────────────────────────────────────
        if section:
            lc = ws.cell(row=ROW_LABEL, column=COL_OFFSET, value=section.title)
            if n_cols > 1:
                ws.merge_cells(start_row=ROW_LABEL, start_column=COL_OFFSET,
                               end_row=ROW_LABEL, end_column=end_col)
            lc.fill      = PatternFill("solid", fgColor=t.color_label_bg)
            lc.font      = Font(name=t.font_name, size=t.font_size_label,
                                bold=True, color=t.color_label_fg)
            lc.alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[ROW_LABEL].height = H_LABEL

        # Filas debajo de la barra
        for r in ROWS_BELOW:
            ws.row_dimensions[r].height = H_BELOW

        # ── Leyenda (fila 20) ─────────────────────────────────────────────────
        ws.row_dimensions[ROW_LEGEND].height = 18.0
        ws.cell(row=ROW_LEGEND, column=COL_OFFSET, value="Leyenda:").font = \
            Font(name=t.font_name, size=8, bold=True)

        # Col A spacer
        ws.column_dimensions["A"].width = 2.5

        # Secciones adicionales (si hay más de 1)
        if len(layout.sections) > 1:
            r = ROW_LABEL + len(ROWS_BELOW) + 3
            for s in layout.sections[1:]:
                for i, col in enumerate(s.columns):
                    c_idx = COL_OFFSET + i
                    cell  = ws.cell(row=r, column=c_idx, value=col.label)
                    if not col.is_ellipsis:
                        cell.fill = PatternFill("solid", fgColor=t.color_year_bg)
                        cell.font = Font(name=t.font_name, size=t.font_size_year,
                                         bold=True, color=t.color_year_fg)
                        cell.alignment = Alignment(horizontal="center", vertical="center")
                    ws.row_dimensions[r].height = H_BAR
                r += 1
                lc2 = ws.cell(row=r, column=COL_OFFSET, value=s.title)
                nc2 = len(s.columns)
                if nc2 > 1:
                    ws.merge_cells(start_row=r, start_column=COL_OFFSET,
                                   end_row=r, end_column=COL_OFFSET + nc2 - 1)
                lc2.fill = PatternFill("solid", fgColor=t.color_label_bg)
                lc2.font = Font(name=t.font_name, size=t.font_size_label,
                                bold=True, color=t.color_label_fg)
                lc2.alignment = Alignment(horizontal="center", vertical="center")
                ws.row_dimensions[r].height = H_LABEL
                r += 7

    # ── Drawings ──────────────────────────────────────────────────────────────

    def _inject_drawings(self, out_path: Path):
        tmp = out_path.with_suffix(".~tmp.xlsx")
        shutil.copy(out_path, tmp)

        with zipfile.ZipFile(tmp, "r") as src, \
             zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as dst:

            existing   = set(src.namelist())
            sheet_rels = {f"xl/worksheets/_rels/sheet{s['idx']}.xml.rels"
                          for s in self._sheets}

            for name in existing:
                if name not in sheet_rels:
                    dst.writestr(name, src.read(name))

            for s in self._sheets:
                i    = s["idx"]
                dxml = self._drawing_xml(s["layout"])
                dst.writestr(f"xl/drawings/drawing_tg{i}.xml", dxml)
                dst.writestr(f"xl/worksheets/_rels/sheet{i}.xml.rels",
                             self._sheet_rel(i, existing, src))

        tmp.unlink()

    def _sheet_rel(self, idx, existing, src) -> str:
        rname  = f"xl/worksheets/_rels/sheet{idx}.xml.rels"
        new_r  = (f'<Relationship Id="rIdDRW1" '
                  f'Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                  f'relationships/drawing" '
                  f'Target="../drawings/drawing_tg{idx}.xml"/>')
        if rname in existing:
            c = src.read(rname).decode("utf-8")
            return c.replace("</Relationships>", f"{new_r}</Relationships>")
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/'
            'package/2006/relationships">'
            f'{new_r}</Relationships>'
        )

    def _drawing_xml(self, layout: LayoutResult) -> str:
        shapes: list[str] = []
        sid    = 1
        section = layout.sections[0] if layout.sections else None
        if not section:
            return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                    f'<xdr:wsDr xmlns:xdr="{NS_XDR}" xmlns:a="{NS_A}"></xdr:wsDr>')

        # Calcular anchos de columna en unidades Excel y en EMU
        col_widths_units = []
        for col in section.columns:
            if col.is_ellipsis:
                col_widths_units.append(WIDTH_ELLIPSIS)
            else:
                col_widths_units.append(max(WIDTH_MIN, len(col.events) * WIDTH_PER_HITO))

        # Acumular posición X en EMU para cada columna
        col_x_emu = []
        x = 0
        for w in col_widths_units:
            col_x_emu.append(x)
            x += int(w * EMU_PER_COL_UNIT)

        for c_idx, col in enumerate(section.columns):
            if col.is_ellipsis or not col.events:
                continue

            n   = len(col.events)
            col_xdr = COL_OFFSET - 1 + c_idx  # 0-indexed para XDR
            col_w_emu = int(col_widths_units[c_idx] * EMU_PER_COL_UNIT)

            # Distribuir hitos equidistantemente dentro de la columna
            if n == 1:
                hito_offsets = [col_w_emu // 2 - HITO_CX // 2]
            else:
                total_span = col_w_emu - 2 * HITO_FIRST_EMU
                step = total_span // (n - 1)
                step = max(step, HITO_STEP_EMU)
                hito_offsets = [HITO_FIRST_EMU + j * step for j in range(n)]

            for e_idx, (event, h_off) in enumerate(zip(col.events, hito_offsets)):
                above = (e_idx % 2 == 0)
                fill_xml = self._fill_xml(getattr(event, "status", PENDING))

                # Texto del hito
                label = event.label[:28]
                if event.detected_date and event.detected_date.date_start:
                    d = event.detected_date.date_start
                    label += f" {d.day:02d}/{d.month:02d}"

                font_color = self._font_color(getattr(event, "status", PENDING))

                if above:
                    row_shape = max(0, ROW_BAR - 4)  # 0-indexed
                    row_shape_end = ROW_BAR - 2
                    row_conn_top  = ROW_BAR - 2
                    row_conn_bot  = ROW_BAR - 1
                else:
                    row_shape     = ROW_LABEL       # 0-indexed
                    row_shape_end = ROW_LABEL + 2
                    row_conn_top  = ROW_LABEL - 1
                    row_conn_bot  = ROW_LABEL + 1

                shapes.append(self._shape_xml(
                    sid, col_xdr, row_shape, row_shape_end,
                    h_off, fill_xml, font_color, label,
                ))
                sid += 1
                shapes.append(self._connector_xml(
                    sid, col_xdr, row_conn_top, row_conn_bot,
                    h_off + HITO_CX // 2,
                ))
                sid += 1

        # Leyenda shapes
        legend_shapes = self._legend_xml(sid)
        shapes.extend(legend_shapes)

        body = "\n".join(shapes)
        return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                f'<xdr:wsDr xmlns:xdr="{NS_XDR}" xmlns:a="{NS_A}">'
                f'{body}</xdr:wsDr>')

    # ── Colores en XML ────────────────────────────────────────────────────────

    @staticmethod
    def _fill_xml(status: str) -> str:
        if status == DONE:
            # Gris — igual que leyenda "Ejecutado" del modelo
            return '<a:solidFill><a:schemeClr val="bg1"><a:lumMod val="75000"/></a:schemeClr></a:solidFill>'
        elif status == ACTIVE:
            return '<a:solidFill><a:srgbClr val="1F497D"/></a:solidFill>'
        else:  # PENDING
            return '<a:solidFill><a:srgbClr val="F3EAAB"/></a:solidFill>'

    @staticmethod
    def _font_color(status: str) -> str:
        if status == PENDING:
            return "333333"
        return "FFFFFF"

    # ── Shape XML ─────────────────────────────────────────────────────────────

    @staticmethod
    def _shape_xml(sid, col_xdr, row_from, row_to,
                    col_off, fill_xml, font_color, text) -> str:
        # Dividir texto en máx 2 líneas
        parts = text.rsplit(" ", 1) if len(text) > 20 else [text]
        para_xml = "".join(
            f'<a:p><a:r>'
            f'<a:rPr lang="es-PE" sz="700" b="1" dirty="0">'
            f'<a:solidFill><a:srgbClr val="{font_color}"/></a:solidFill>'
            f'</a:rPr>'
            f'<a:t>{p}</a:t></a:r></a:p>'
            for p in parts
        )
        return (
            f'<xdr:twoCellAnchor moveWithCells="1">'
            f'<xdr:from>'
            f'<xdr:col>{col_xdr}</xdr:col><xdr:colOff>{col_off}</xdr:colOff>'
            f'<xdr:row>{row_from}</xdr:row><xdr:rowOff>57150</xdr:rowOff>'
            f'</xdr:from>'
            f'<xdr:to>'
            f'<xdr:col>{col_xdr}</xdr:col><xdr:colOff>{col_off + HITO_CX}</xdr:colOff>'
            f'<xdr:row>{row_to}</xdr:row><xdr:rowOff>57150</xdr:rowOff>'
            f'</xdr:to>'
            f'<xdr:sp macro="" textlink="">'
            f'<xdr:nvSpPr>'
            f'<xdr:cNvPr id="{sid}" name="hito_{sid}"/>'
            f'<xdr:cNvSpPr/>'
            f'</xdr:nvSpPr>'
            f'<xdr:spPr>'
            f'<a:xfrm><a:off x="0" y="0"/>'
            f'<a:ext cx="{HITO_CX}" cy="{HITO_CY}"/></a:xfrm>'
            f'<a:prstGeom prst="roundRect"><a:avLst/></a:prstGeom>'
            f'{fill_xml}'
            f'<a:ln w="6350"><a:noFill/></a:ln>'
            f'</xdr:spPr>'
            f'<xdr:txBody>'
            f'<a:bodyPr rtlCol="0" anchor="ctr"/>'
            f'<a:lstStyle/>'
            f'{para_xml}'
            f'</xdr:txBody>'
            f'</xdr:sp>'
            f'<xdr:clientData/>'
            f'</xdr:twoCellAnchor>'
        )

    @staticmethod
    def _connector_xml(sid, col_xdr, row_top, row_bot, col_off) -> str:
        return (
            f'<xdr:twoCellAnchor>'
            f'<xdr:from>'
            f'<xdr:col>{col_xdr}</xdr:col><xdr:colOff>{col_off}</xdr:colOff>'
            f'<xdr:row>{row_top}</xdr:row><xdr:rowOff>190500</xdr:rowOff>'
            f'</xdr:from>'
            f'<xdr:to>'
            f'<xdr:col>{col_xdr}</xdr:col><xdr:colOff>{col_off + 1000}</xdr:colOff>'
            f'<xdr:row>{row_bot}</xdr:row><xdr:rowOff>0</xdr:rowOff>'
            f'</xdr:to>'
            f'<xdr:cxnSp macro="">'
            f'<xdr:nvCxnSpPr>'
            f'<xdr:cNvPr id="{sid}" name="conn_{sid}"/>'
            f'<xdr:cNvCxnSpPr/>'
            f'</xdr:nvCxnSpPr>'
            f'<xdr:spPr>'
            f'<a:xfrm><a:off x="{col_off}" y="0"/><a:ext cx="0" cy="390525"/></a:xfrm>'
            f'<a:prstGeom prst="straightConnector1"><a:avLst/></a:prstGeom>'
            f'<a:ln w="12700">'
            f'<a:solidFill><a:srgbClr val="FF0000"/></a:solidFill>'
            f'<a:tailEnd type="oval"/>'
            f'</a:ln>'
            f'</xdr:spPr>'
            f'</xdr:cxnSp>'
            f'<xdr:clientData/>'
            f'</xdr:twoCellAnchor>'
        )

    def _legend_xml(self, start_sid: int) -> list[str]:
        """Leyenda igual que el modelo: Ejecutado | En curso | Pendiente."""
        shapes = []
        sid    = start_sid
        # Posición de la leyenda: fila ROW_LEGEND, cols 1,2,3
        items = [
            (DONE,    "Ejecutado",          "B8B8B8", "FFFFFF", self._fill_xml(DONE)),
            (ACTIVE,  "En curso",           "1F497D", "FFFFFF", self._fill_xml(ACTIVE)),
            (PENDING, "Pendiente de ejecutar","F3EAAB","333333", self._fill_xml(PENDING)),
        ]
        row_leg = ROW_LEGEND - 1  # 0-indexed
        col_leg = COL_OFFSET - 1  # col B en 0-indexed = 1

        for i, (status, text, fill, fc, fill_xml) in enumerate(items):
            shapes.append(self._shape_xml(
                sid, col_leg + i, row_leg, row_leg + 1,
                200000, fill_xml, fc, text,
            ))
            sid += 1
        return shapes

    @staticmethod
    def _safe(name: str) -> str:
        return "".join(c if c not in r'\/:*?"<>|[]' else "_" for c in name)[:31]
