"""
timeline_builder.py  v4
Siempre usa columnas ANUALES (igual que el modelo).
Dentro de cada columna año, los hitos se ordenan cronológicamente
y se distribuyen de izquierda a derecha.

Lógica de color por hito:
  fecha < hoy  → DONE   (gris,   ejecutado)
  fecha = hoy  → ACTIVE (azul oscuro, en curso)
  fecha > hoy  → PENDING (amarillo, pendiente)
"""
from __future__ import annotations
import logging
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Optional

from core.file_parser import ParseResult, TimelineEvent
from utils.date_detector import DateGranularity

logger = logging.getLogger(__name__)

MONTH_ES = ["","Ene","Feb","Mar","Abr","May","Jun",
            "Jul","Ago","Sep","Oct","Nov","Dic"]

# Estado de cada hito
DONE    = "done"      # gris  — ya ejecutado
ACTIVE  = "active"    # azul oscuro — en curso / fecha más próxima
PENDING = "pending"   # amarillo — aún no ocurre


@dataclass
class TimelineColumn:
    label: str
    is_ellipsis: bool = False
    events: list[TimelineEvent] = field(default_factory=list)
    year: Optional[int] = None
    month: Optional[int] = None


@dataclass
class TimelineSection:
    title: str
    columns: list[TimelineColumn] = field(default_factory=list)


@dataclass
class BuilderWarning:
    timeline_index: int
    message: str
    events_compressed: int


@dataclass
class LayoutResult:
    project_title: str
    sections: list[TimelineSection]
    total_columns: int
    was_synthesized: bool
    granularity_used: str = "annual"
    warnings: list[BuilderWarning] = field(default_factory=list)
    source_file: str = ""


@dataclass
class BuilderConfig:
    granularity: str = "annual"   # siempre anual — no cambiar
    max_columns: int = 14
    language: str    = "es"
    today: Optional[date] = None  # inyectable para tests


class TimelineBuilder:

    def __init__(self, config: Optional[BuilderConfig] = None):
        self.config = config or BuilderConfig()
        self.today  = self.config.today or date.today()

    # ── API pública ───────────────────────────────────────────────────────────

    def build(self, parse_result: ParseResult,
              timeline_index: int = 0) -> LayoutResult:
        warnings: list[BuilderWarning] = []
        sections_raw = self._split_sections(parse_result.events)
        built = []

        for title, events in sections_raw.items():
            # Asignar estado de color a cada evento
            self._assign_status(events)
            cols = self._build_annual_columns(events)
            cols, n_comp = self._synthesize(cols)
            if n_comp:
                warnings.append(BuilderWarning(
                    timeline_index=timeline_index,
                    message=(f"Sección '{title}': {n_comp} año(s) comprimidos "
                             f"en '…' (límite={self.config.max_columns} cols)."),
                    events_compressed=n_comp,
                ))
            built.append(TimelineSection(title=title, columns=cols))

        total = max((len(s.columns) for s in built), default=0)
        layout = LayoutResult(
            project_title   = self._clean_title(parse_result),
            sections        = built,
            total_columns   = total,
            was_synthesized = any(w.events_compressed for w in warnings),
            granularity_used= "annual",
            warnings        = warnings,
            source_file     = parse_result.source_file,
        )
        logger.info("Layout '%s' | %d secc | %d cols | hoy=%s",
                    layout.project_title[:40], len(built), total, self.today)
        return layout

    # ── Estado de color ───────────────────────────────────────────────────────

    def _assign_status(self, events: list[TimelineEvent]) -> None:
        """
        Asigna event.status según la fecha comparada con hoy.
        Marca el evento con fecha más cercana al futuro como ACTIVE.
        """
        today = self.today
        future = [e for e in events
                  if e.detected_date and e.detected_date.date_start
                  and e.detected_date.date_start.date() >= today]

        # El más próximo al futuro = ACTIVE
        active_event = None
        if future:
            active_event = min(future,
                               key=lambda e: e.detected_date.date_start.date())

        for e in events:
            if not e.detected_date or not e.detected_date.date_start:
                e.status = PENDING
                continue
            d = e.detected_date.date_start.date()
            if e is active_event:
                e.status = ACTIVE
            elif d < today:
                e.status = DONE
            else:
                e.status = PENDING

    # ── Columnas anuales ──────────────────────────────────────────────────────

    def _build_annual_columns(self,
                               events: list[TimelineEvent]) -> list[TimelineColumn]:
        cols: dict[int, TimelineColumn] = {}
        for e in events:
            key = e.year or 9999
            if key not in cols:
                cols[key] = TimelineColumn(
                    label=str(key) if key != 9999 else "S/F",
                    year=key if key != 9999 else None,
                )
            # Ordenar dentro de la columna por fecha al insertar
            cols[key].events.append(e)

        # Ordenar eventos dentro de cada columna cronológicamente
        for col in cols.values():
            col.events.sort(key=lambda ev: (
                ev.detected_date.date_start if ev.detected_date and
                ev.detected_date.date_start else datetime.max
            ))

        return [cols[k] for k in sorted(cols)]

    # ── Agrupación en secciones ───────────────────────────────────────────────

    @staticmethod
    def _clean_title(pr: ParseResult) -> str:
        """
        Título limpio con 4 niveles de fallback:
        1. project_title real de Gemini (largo y descriptivo)
        2. Fase principal de los eventos (ej. "PROCESO DE SELECCIÓN")
        3. Nombre del archivo limpio
        4. "Línea de Tiempo"
        """
        import os
        GENERIC = {"", "general", "ocr", "visual",
                   "línea de tiempo", "linea de tiempo",
                   "timeline", "cronograma"}
        EXTS = {'.png', '.jpg', '.jpeg', '.docx', '.pdf', '.xlsx', '.xls'}

        # Nivel 1: project_title de Gemini
        raw = (pr.project_title or "").strip()
        if raw:
            # Limpiar si es nombre de archivo
            if any(raw.lower().endswith(e) for e in EXTS):
                raw = os.path.splitext(raw)[0].replace('_',' ').replace('-',' ').title()
            # Aceptar si es descriptivo (>8 chars y no genérico)
            if len(raw) > 8 and raw.lower() not in GENERIC:
                return raw

        # Nivel 2: fase del primer evento con fecha
        dated = [e for e in pr.events
                 if e.detected_date and e.phase
                 and e.phase.lower() not in GENERIC]
        if dated:
            return dated[0].phase

        # Nivel 3: nombre del archivo limpio
        if pr.source_file:
            name = os.path.splitext(pr.source_file)[0]
            name = name.replace('_',' ').replace('-',' ').strip()
            if name.lower() not in GENERIC:
                return name.title()

        return "Línea de Tiempo"

    def _split_sections(self,
                         events: list[TimelineEvent]) -> dict[str, list[TimelineEvent]]:
        sections: dict[str, list[TimelineEvent]] = {}
        current = "LÍNEA DE TIEMPO"

        for e in events:
            if e.is_section_header:
                current = e.label
            else:
                sections.setdefault(current, []).append(e)

        # Si todos los eventos tienen la misma fase, usar esa como título
        if len(sections) == 1:
            phases = set(e.phase for e in list(sections.values())[0] if e.phase)
            if phases and list(phases)[0] not in ("", "General", "OCR", "Visual"):
                key = list(sections.keys())[0]
                title = list(phases)[0]
                if title != key:
                    sections = {title: sections[key]}

        return {k: v for k, v in sections.items() if v}

    # ── Síntesis ──────────────────────────────────────────────────────────────

    def _synthesize(self, cols: list[TimelineColumn]) -> tuple[list[TimelineColumn], int]:
        max_c = self.config.max_columns
        if len(cols) <= max_c:
            return cols, 0

        result: list[TimelineColumn] = []
        pending_ellipsis = False
        compressed = 0

        for col in cols:
            if not col.events:
                pending_ellipsis = True
                compressed += 1
            else:
                if pending_ellipsis:
                    result.append(TimelineColumn(label="…", is_ellipsis=True))
                    pending_ellipsis = False
                result.append(col)

        if pending_ellipsis:
            result.append(TimelineColumn(label="…", is_ellipsis=True))

        if len(result) > max_c:
            first, last = result[0], result[-1]
            middle = result[1:-1]
            budget = max_c - 3
            top = sorted(middle, key=lambda c: len(c.events), reverse=True)[:budget]
            top = sorted(top, key=lambda c: c.year or 0)
            result = ([first, TimelineColumn(label="…", is_ellipsis=True)]
                      + top
                      + [TimelineColumn(label="…", is_ellipsis=True), last])
            compressed += len(cols) - len(result)

        return result, compressed
